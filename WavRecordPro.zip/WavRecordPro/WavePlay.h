// CWavePlay.h: interface for the CCWavePlayer class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include <mmsystem.h>
#pragma comment(lib, "winmm.lib")

#include <shlwapi.h>
#pragma comment(lib, "shlwapi.lib")

#define QUEUE_BUFFER_SIZE (4096)
#define WM_USER_CLOSE (WM_USER + 2242)
#define WM_USER_PROGESS (WM_USER + 833)

class CWavePlay: public CWnd  
{
public:
	CWavePlay();
	virtual ~CWavePlay();

public:
	void Init(HWND hwndParent, LPRECT lpRect, DWORD dwBufferSize, UINT nDeviceID = WAVE_MAPPER); // Init params and graphics window
	BOOL Open(CString strFilePath); // Check validity of wav file and open a waveform-audio output device for playback
	void Play(CString strFilePath); // Start to playback
	void Pause(); // Pause playing
	void Restart(); // Resumes playback on a paused waveform-audio output device 
	void Stop(); // Stop playing
	BOOL IsPlaying(){ return m_bPlaying; } // Is playing now
	BOOL IsPaused(){ return m_bPaused; } // Is paused now
	void SetVolume(DWORD dwVolume); // Set volume for left and right channel volume together
	void SetVolumeLR(WORD wLeft, WORD wRight); // Set volume for left and right channel volume dividually
	void GetVolume(DWORD& dwVolume); // Get volume level: low-order word contains the left-channel volume
	void GetVolumeLR(WORD& wLeft, WORD& wRight); // Get volume level dividually
	void GetDevNum(UINT &nDevNum); // Get the number of waveform-audio output devices present in the system
	void GetDevID(UINT& nDevID); // Get the device identifier for the given waveform-audio output device
	void SetDevID(UINT nDevID); // Set the device identifier - but be valid at next time
	void GetProductNames(CStringArray& strArrProductNames); // Get product names of every waveform-audio output devices present in the system
	int GetNumDevsOut(){ return waveOutGetNumDevs(); } // Get number of waveform-audio output devices
	void GetWaveOutCaps(WAVEOUTCAPS& caps){ caps = m_caps; } // Get capabilities of the waveform-audio output device
	void GetWaveFormatEx(WAVEFORMATEX& format){ format = m_format; } // Get the format of waveform-audio data
	int GetRangeMax(){ return m_nRangeMax; } // Get max range value for progress
	void SetPosition(long lPos); // Set the current playback position

	// Note:
	// The parameter of these functions below is multiplier value
	// Means that the setting or getting indicates the current change 
	// in pitch or playback rate from the original authored setting or getting
	// The multiplier is specified as a fixed-point value
	// The high-order word contains the signed integer part of the number
	// and the low-order word contains the fractional part: 0x8000 represents 1/2, 0x4000 represents 1/4 ...
	// So, 0x0002c000 specifies a multiplier of 2.75
	//
	void SetPitch(DWORD dwPitch); // Set the pitch for the specified waveform-audio output device
	void GetPitch(DWORD& dwPitch); // Get the current pitch setting for the specified waveform-audio output device
	void SetPlaybackRate(DWORD dwRate); // Set the playback rate for the specified waveform-audio output 
	void GetPlaybackRate(DWORD& dwRate); // Get the current playback rate for the specified waveform-audio output device

	// Set and get colors for background, waveform, text and split line
	void SetColors(COLORREF clrBkgd, COLORREF clrWave, COLORREF clrText, COLORREF clrSplit);
	void GetColors(COLORREF& clrBkgd, COLORREF& clrWave, COLORREF& clrText, COLORREF& clrSplit);
	
private:	
	void Close(); // Closes the given waveform-audio output device
	BOOL Create(HWND hWndParent, LPRECT lpRect = NULL); // Create a window for drawing waveform
	void Release(); // Free buffers
	void MyMessageBox(CString strErr, UINT nType); // My message box
	BOOL CheckValidity(CString strFilePath); // Check the validity of a wave file
	BOOL AllocateMemory(DWORD dwBufferSize); // Allocate memory for array of out data and wave header
	BOOL ReadSoundDataFromFile(LPVOID pData, int& dwSize); // Read sound data form file
	BOOL AddOutputBufferToQueue(int nIndex, int nSize); // Add output buffer to playing queue
	void CalcForProgess(); // Calculate parameters(step, range max ... ) for progress silder

	// Callback function used with the waveform-audio output device
	BOOL static CALLBACK waveOutProc(HWAVEOUT hWaveOut, UINT uMsg, DWORD dwInstance, DWORD dwParam1, DWORD dwParam2);

	//////////////////////////////////////////////////////////////////////////////////////////
	void DrawWindowBG(CDC *pDC); // Draw background of created window
	CRect GetDrawRect(BOOL bLeft); // Get drawing rect of left or right
	void DrawWave(DWORD dwSize); // Draw waveform 
	void DrwaWave8(CDC *pDC, BYTE *pData, DWORD dwSize, BOOL bLeft); // Draw 8bits waveform
	void DrwaWave16(CDC *pDC, SHORT *pData, DWORD dwSize, BOOL bLeft); // Draw 16bits waveform
	DWORD SplitStereo2Mono(WAVEFORMATEX format, PBYTE pByData, DWORD dwSize); // Split stereo data to mono one

protected:
	HWND m_hParentWnd; // Handle of parent window
	CRect m_rcDrawWnd; // Rect of drawing window
	CPen m_penText; // Pen for text drawing
	CPen m_PenWave; // Pen for waveform drawing
	CPen m_penLine; // Pen for line drawing
	PBYTE m_pByOutDataL; // Pointer point to left channel data
	PBYTE m_pByOutDataR; // Pointer point to right channel data
	COLORREF m_clrBkgd; // Color of background
	COLORREF m_clrWaveform; // Color of waveform
	COLORREF m_clrText; // Color of text
	COLORREF m_clrSplit; // Color of split line

	////////////////////////////////////////////////////////////////////////////////
	BOOL m_bPlaying; // Is playing or not
	BOOL m_bPaused; // Is paused or not
	UINT m_nDeviceID; // Identifier of the waveform-audio output device
	UINT m_nNumDevsOut; // Number of waveform-audio output devices present in the system
	HMMIO m_hWaveFile; // A handle to an open file
	MMCKINFO m_mmckinfoParent; // RIFF chunk information data structure - Parent
	MMCKINFO m_mmckinfoSubChunk; // RIFF chunk information data structure - Sub Chunk
	DWORD m_dwFmtSize; // "fmt" chunk size
	DWORD m_dwQueBufferSize; // Buffer size of playing queque
	DWORD m_dwQueue; // Number of playing queues
	DWORD m_dwBufferNumInQueue; // Buffer number in playing queue
	DWORD m_dwVolume; // Volume value
	HWAVEOUT m_hWaveOut; // Handle of open waveform-audio output device
	WAVEFORMATEX m_format; // Format of waveform-audio data
	WAVEOUTCAPS m_caps; // Capabilities of a waveform-audio output device
	PBYTE *m_pArrOutData; // Pointer point to array of out data
	PWAVEHDR *m_pArrHdr; // Pointer point to array of wave header
	
	////////////////////////////////////////////////////////////////
	DWORD m_dwDataSize; // Size of 'data' chunk
	DWORD m_dwReadDataCount; // Number of readed bytes
	int m_nStep1; // m_nStep1 = m_dwDataSize / m_dwQueBufferSize
	int m_nStep2; // m_nStep2 = m_nStep1 / m_nRangeMax
	int m_nRangeMax; // range max value for playing control slider
	int m_nInitPos; // The pos of file pointer point to 'data' chunk
	int m_nStepCount; // Counter for reading sound data from file

	enum ERR_TYPES
	{
		eERR_ERROR, // MB_OK | MB_ICONERROR
		eERR_WARNING, // MB_OK | MB_ICONWARNING
		eERR_INFO // MB_OK | MB_ICONINFORMATION
	};

protected:
	//{{AFX_MSG(CWavePlay)
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg LRESULT OnClose(WPARAM wParam, LPARAM lParam);
	//}}AFX_MSG
    LRESULT OnMM_WOM_DONE(WPARAM wParam, LPARAM lParam);
	LRESULT OnMM_WOM_CLOSE(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};
