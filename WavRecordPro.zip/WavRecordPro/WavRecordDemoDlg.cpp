// WavRecordDemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WavRecordDemo.h"
#include "WavRecordDemoDlg.h"
#include "FileDialogEx.h"
#include "ColorDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWavRecordDemoDlg dialog

CWavRecordDemoDlg::CWavRecordDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CWavRecordDemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CWavRecordDemoDlg)
	m_checkL = TRUE;
	m_checkR = TRUE;
	m_rdMono = -1;
	m_rdStereo = 0;
	m_rdAlone = -1;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_nSelDevIn = 0;
	m_nSelDevOut = 0;
	m_nSelBufSize = 4;
	m_nTimeCnt = 0;
}

void CWavRecordDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWavRecordDemoDlg)
	DDX_Control(pDX, IDC_COMBO_BUF_SIZE, m_combBufSize);
	DDX_Control(pDX, IDC_COMBO_SF, m_combSF);
	DDX_Control(pDX, IDC_COMBO_SB, m_combSB);
	DDX_Control(pDX, IDC_COMBO_DEV_OUT, m_combDevOut);
	DDX_Control(pDX, IDC_COMBO_DEV_IN, m_combDevIn);
	DDX_Check(pDX, IDC_CHECK_L, m_checkL);
	DDX_Check(pDX, IDC_CHECK_R, m_checkR);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CWavRecordDemoDlg, CDialog)
	//{{AFX_MSG_MAP(CWavRecordDemoDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_RD_ALONG, OnRdAlong)
	ON_BN_CLICKED(IDC_RD_MONO, OnRdMono)
	ON_BN_CLICKED(IDC_RD_STEORO, OnRdSteoro)
	ON_BN_CLICKED(IDC_BTN_START, OnBtnStart)
	ON_BN_CLICKED(IDC_BTN_STOP, OnBtnStop)
	ON_BN_CLICKED(IDC_BTN_PLAY, OnBtnPlay)
	ON_BN_CLICKED(IDC_BTN_COMB, OnBtnComb)
	ON_CBN_SELCHANGE(IDC_COMBO_DEV_IN, OnSelchangeComboDevIn)
	ON_CBN_SELCHANGE(IDC_COMBO_DEV_OUT, OnSelchangeComboDevOut)
	ON_CBN_SELCHANGE(IDC_COMBO_BUF_SIZE, OnSelchangeComboBufSize)
	ON_BN_CLICKED(IDC_BTN_STOP_PLAY, OnBtnStopPlay)
	ON_BN_CLICKED(IDC_BTN_COLORS, OnBtnColors)
	ON_MESSAGE(WM_USER_CLOSE, OnPlayingStoped)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWavRecordDemoDlg message handlers

BOOL CWavRecordDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	InitControls();
	m_wavePlay.Init(GetSafeHwnd(), m_rcWindow, m_nSelBufSize * 1024, m_nSelDevOut);
	m_waveRecord.Init(GetSafeHwnd(), m_rcWindow, m_nSelBufSize * 1024, m_nSelDevIn);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CWavRecordDemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CWavRecordDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CWavRecordDemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

CString CWavRecordDemoDlg::GetAppDir()
{
	int nSlash = 0;
	static CString s_strPath;
	static BOOL bCalled(FALSE);
	
	if(bCalled)
	{
		return s_strPath;
	}
	else
	{
		bCalled = TRUE;
		
		#ifdef UNICODE
			LPWSTR pChDir = s_strPath.GetBuffer(MAX_PATH);
		#else
			LPSTR pChDir = s_strPath.GetBuffer(MAX_PATH);
		#endif
		
		GetModuleFileName(AfxGetInstanceHandle(), pChDir, MAX_PATH);
		s_strPath.ReleaseBuffer();
		nSlash = s_strPath.ReverseFind(_T('\\'));
		s_strPath = s_strPath.Left(nSlash + 1);
	}
	return s_strPath;
}

void CWavRecordDemoDlg::InitControls()
{
	int i = 0;
	CStringArray strArrProductNames;

	m_wavePlay.GetProductNames(strArrProductNames);
	for(i = 0; i < strArrProductNames.GetSize(); i++)
	{
		m_combDevOut.AddString(strArrProductNames.GetAt(i));
		m_combDevOut.SetCurSel(i);
	}

	m_waveRecord.GetProductNames(strArrProductNames);
	for(i = 0; i < strArrProductNames.GetSize(); i++)
	{
		m_combDevIn.AddString(strArrProductNames.GetAt(i));
		m_combDevIn.SetCurSel(i);
	}

	m_combSF.SetCurSel(2);
	m_combSB.SetCurSel(1);
	m_combBufSize.SetCurSel(3);

	((CButton*)GetDlgItem(IDC_RD_STEORO))->SetCheck(TRUE);
	GetDlgItem(IDC_CHECK_L)->EnableWindow(FALSE);
	GetDlgItem(IDC_CHECK_R)->EnableWindow(FALSE);

	GetDlgItem(IDC_STATIC_TIMER)->GetWindowRect(&m_rcTimer);
	GetDlgItem(IDC_STATIC_WINDOW)->GetWindowRect(&m_rcWindow);
	ScreenToClient(&m_rcTimer);
	ScreenToClient(&m_rcWindow);
}

void CWavRecordDemoDlg::EnableControls(BOOL bEnable)
{
	if(!bEnable)
	{
		GetDlgItem(IDC_CHECK_L)->EnableWindow(bEnable);
		GetDlgItem(IDC_CHECK_R)->EnableWindow(bEnable);
	}	
	else
	{
		UpdateData(TRUE);
		if(!m_rdAlone)
		{
			GetDlgItem(IDC_CHECK_L)->EnableWindow(bEnable);
			GetDlgItem(IDC_CHECK_R)->EnableWindow(bEnable);
		}
		else
		{
			GetDlgItem(IDC_CHECK_L)->EnableWindow(!bEnable);
			GetDlgItem(IDC_CHECK_R)->EnableWindow(!bEnable);
		}
	}
	GetDlgItem(IDC_BTN_START)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_PLAY)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_COMB)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_STOP_PLAY)->EnableWindow(bEnable);
	GetDlgItem(IDC_BTN_COLORS)->EnableWindow(bEnable);
	GetDlgItem(IDC_RD_MONO)->EnableWindow(bEnable);
	GetDlgItem(IDC_RD_STEORO)->EnableWindow(bEnable);
	GetDlgItem(IDC_RD_ALONG)->EnableWindow(bEnable);
	GetDlgItem(IDC_COMBO_DEV_IN)->EnableWindow(bEnable);
	GetDlgItem(IDC_COMBO_DEV_OUT)->EnableWindow(bEnable);
	GetDlgItem(IDC_COMBO_SF)->EnableWindow(bEnable);
	GetDlgItem(IDC_COMBO_SB)->EnableWindow(bEnable);
	GetDlgItem(IDC_COMBO_BUF_SIZE)->EnableWindow(bEnable);
}

void CWavRecordDemoDlg::OnRdMono() 
{
	m_rdMono = 0;
	m_rdStereo = -1;
	m_rdAlone = -1;
	GetDlgItem(IDC_CHECK_L)->EnableWindow(FALSE);
	GetDlgItem(IDC_CHECK_R)->EnableWindow(FALSE);
}

void CWavRecordDemoDlg::OnRdSteoro() 
{
	m_rdMono = -1;
	m_rdStereo = 0;
	m_rdAlone = -1;
	GetDlgItem(IDC_CHECK_L)->EnableWindow(FALSE);
	GetDlgItem(IDC_CHECK_R)->EnableWindow(FALSE);
}

void CWavRecordDemoDlg::OnRdAlong() 
{
	m_rdMono = -1;
	m_rdStereo = -1;
	m_rdAlone = 0;
	GetDlgItem(IDC_CHECK_L)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHECK_R)->EnableWindow(TRUE);
}

void CWavRecordDemoDlg::OnBtnStart() 
{
	WORD wChannels = 0;
	int nSamplesPerSec = 44100;
	int nBitsPerSample = 16;

	m_nTimeCnt = 0;
	SetTimer(2, 1000, NULL);
	EnableControls(FALSE);

	if(m_combSF.GetCurSel() != 0)
	{
		nSamplesPerSec = (m_combSF.GetCurSel() * 2) * 11025;
	}
	nBitsPerSample = (m_combSB.GetCurSel() + 1) * 8;
	wChannels = GetChannels();
	m_waveRecord.Record(wChannels, nSamplesPerSec, nBitsPerSample);
	m_waveRecord.SaveRecordData2File(GetAppDir() + _T("Recorded.wav"));
}

void CWavRecordDemoDlg::OnBtnStop() 
{
	KillTimer(2);
	EnableControls(TRUE);
	m_waveRecord.StopRecord();
}

WORD CWavRecordDemoDlg::GetChannels()
{
	UpdateData(TRUE);
	WORD wChannels = CWaveRecord::eCH_STEREO;
	
	if(!m_rdMono)
	{
		wChannels = CWaveRecord::eCH_MONO;
	}
	else if(!m_rdStereo)
	{
		wChannels = CWaveRecord::eCH_STEREO;
	}
	if(!m_rdAlone)
	{
		if(m_checkL && !m_checkR)
		{
			wChannels = CWaveRecord::eCH_ALONE_L;
		}
		else if(!m_checkL && m_checkR)
		{
			wChannels = CWaveRecord::eCH_ALONE_R;
		}
		else if(m_checkL && m_checkR)
		{
			wChannels = CWaveRecord::eCH_ALONE_ALL;
		}
		else
		{
			m_checkL = m_checkR = TRUE;
			wChannels = CWaveRecord::eCH_ALONE_ALL;
		}
	}

	UpdateData(FALSE);
	return wChannels;
}

void CWavRecordDemoDlg::OnBtnPlay() 
{
	CFileDialogEx dlg(TRUE, NULL, NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, _T("*.wav|*.wav||"));
	dlg.m_ofn.lpstrInitialDir = GetAppDir();
	
	if(m_wavePlay.IsPlaying())
	{
		m_wavePlay.Pause();
		GetDlgItem(IDC_BTN_PLAY)->SetWindowText(_T("�ط�¼��"));
		return;
	}
	else if(m_wavePlay.IsPaused())
	{
		m_wavePlay.Restart();
		GetDlgItem(IDC_BTN_PLAY)->SetWindowText(_T("��ͣ����"));
		return;
	}
	else
	{
		if(dlg.DoModal() == IDOK)
		{
			m_wavePlay.Play(dlg.GetPathName());
			GetDlgItem(IDC_BTN_START)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_STOP)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_COLORS)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_COMB)->EnableWindow(FALSE);
			GetDlgItem(IDC_BTN_PLAY)->SetWindowText(_T("��ͣ����"));
		}
	}
}

void CWavRecordDemoDlg::OnBtnStopPlay() 
{
	if(m_wavePlay.IsPlaying() ||
		m_wavePlay.IsPaused())
	{
		m_wavePlay.Stop();
	}
	GetDlgItem(IDC_BTN_START)->EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_STOP)->EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_COLORS)->EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_COMB)->EnableWindow(TRUE);
	GetDlgItem(IDC_BTN_PLAY)->SetWindowText(_T("�ط�¼��"));
}

LRESULT CWavRecordDemoDlg::OnPlayingStoped(WPARAM wParam, LPARAM lParam)
{
	OnBtnStopPlay();
	return 0L;
}

void CWavRecordDemoDlg::OnSelchangeComboDevIn() 
{
	m_nSelDevIn = m_combDevIn.GetCurSel();
	m_waveRecord.Init(GetSafeHwnd(), m_rcWindow, m_nSelBufSize * 1024, m_nSelDevIn);
}

void CWavRecordDemoDlg::OnSelchangeComboDevOut() 
{
	m_nSelDevOut = m_combDevOut.GetCurSel();
	m_wavePlay.Init(GetSafeHwnd(), m_rcWindow, m_nSelBufSize * 1024, m_nSelDevOut);
}

void CWavRecordDemoDlg::OnSelchangeComboBufSize() 
{
	m_nSelBufSize = m_combBufSize.GetCurSel() + 1;
	m_wavePlay.Init(GetSafeHwnd(), m_rcWindow, m_nSelBufSize * 1024, m_nSelDevOut);
	m_waveRecord.Init(GetSafeHwnd(), m_rcWindow, m_nSelBufSize * 1024, m_nSelDevIn);
}

void CWavRecordDemoDlg::OnClose() 
{
	if(m_wavePlay.IsPlaying() || m_wavePlay.IsPaused())
	{
		m_wavePlay.Stop();
	}
	if(m_waveRecord.IsRecording())
	{
		m_waveRecord.StopRecord();
	}
	CDialog::OnCancel();
}

void CWavRecordDemoDlg::OnBtnColors() 
{
	CColorDlg dlg;
	COLORREF clrBkgd, clrWave;
	COLORREF clrText, clrSplit;
	m_wavePlay.GetColors(clrBkgd, clrWave, clrText, clrSplit);
	dlg.m_clrBkgd = clrBkgd;
	dlg.m_clrWaveform = clrWave;
	dlg.m_clrText = clrText;
	dlg.m_clrSplit = clrSplit;
	if(dlg.DoModal() == IDCANCEL)
	{
		m_wavePlay.SetColors(dlg.m_clrBkgd, dlg.m_clrWaveform, dlg.m_clrText, dlg.m_clrSplit);
	}
}

void CWavRecordDemoDlg::OnBtnComb() 
{
	CCombWavDlg dlg;
	dlg.DoModal();
}

void CWavRecordDemoDlg::OnTimer(UINT nIDEvent) 
{
	CClientDC dc(this);
	CRect rc;
	int nMinute, nSecond;
	CString strRecordedTime;

	if(nIDEvent == 2)
	{
		m_nTimeCnt++;
		nMinute = m_nTimeCnt / 60;
		nSecond = m_nTimeCnt % 60;
		strRecordedTime.Format(_T("¼��ʱ�� -  %.2d : %.2d"), nMinute, nSecond);
		dc.SetBkColor(::GetSysColor(COLOR_3DFACE));
		dc.SetTextColor(RGB(0, 128, 255));
		dc.TextOut(m_rcTimer.left + 13, m_rcTimer.top + 10, strRecordedTime);
	}
	CDialog::OnTimer(nIDEvent);
}
