#if !defined(AFX_COMBWAVDLG_H__2FF800BF_470B_4556_86AC_8A8E65E37D79__INCLUDED_)
#define AFX_COMBWAVDLG_H__2FF800BF_470B_4556_86AC_8A8E65E37D79__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CombWavDlg.h : header file
//

#include <mmsystem.h>
#pragma comment(lib, "winmm.lib")

/////////////////////////////////////////////////////////////////////////////
// CCombWavDlg dialog

class CCombWavDlg : public CDialog
{
// Construction
public:
	CCombWavDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCombWavDlg)
	enum { IDD = IDD_COMB_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCombWavDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	enum ERR_TYPES
	{
		eERR_ERROR, // MB_OK | MB_ICONERROR
		eERR_WARNING, // MB_OK | MB_ICONWARNING
		eERR_INFO // MB_OK | MB_ICONINFORMATION
	};

	// Generated message map functions
	//{{AFX_MSG(CCombWavDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void MyMessageBox(CString strErr, UINT nType);
	int CheckValidity(CString strPath, WAVEFORMATEX& wfx);
	BOOL IsCanCombine(CString strPath1, CString strPath2);
	BOOL CreateWaveFile(HMMIO hWaveFile, LPCTSTR lpszFilePath, WAVEFORMATEX wfx);
	void Combine(CString strPathL, CString strPathR, CString strPathObj);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COMBWAVDLG_H__2FF800BF_470B_4556_86AC_8A8E65E37D79__INCLUDED_)
