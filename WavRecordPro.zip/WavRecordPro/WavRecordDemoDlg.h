// WavRecordDemoDlg.h : header file
//

#if !defined(AFX_WAVRECORDDEMODLG_H__957C49F7_38E9_4A10_B67B_ACF6458F7554__INCLUDED_)
#define AFX_WAVRECORDDEMODLG_H__957C49F7_38E9_4A10_B67B_ACF6458F7554__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "WavePlay.h"
#include "WaveRecord.h"
#include "CombWavDlg.h"
/////////////////////////////////////////////////////////////////////////////
// CWavRecordDemoDlg dialog

class CWavRecordDemoDlg : public CDialog
{
// Construction
public:
	CWavRecordDemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CWavRecordDemoDlg)
	enum { IDD = IDD_WAVRECORDDEMO_DIALOG };
	CComboBox	m_combBufSize;
	CComboBox	m_combSF;
	CComboBox	m_combSB;
	CComboBox	m_combDevOut;
	CComboBox	m_combDevIn;
	BOOL	m_checkL;
	BOOL	m_checkR;
	int		m_rdMono;
	int     m_rdAlone;
	int     m_rdStereo;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWavRecordDemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	CWavePlay m_wavePlay;
	CWaveRecord m_waveRecord;
	CCombWavDlg m_combDlg;
	CRect m_rcWindow;
	CRect m_rcTimer;
	int m_nSelDevIn;
	int m_nSelDevOut;
	int m_nSelBufSize;
	int m_nTimeCnt;

	// Generated message map functions
	//{{AFX_MSG(CWavRecordDemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnRdAlong();
	afx_msg void OnRdMono();
	afx_msg void OnRdSteoro();
	afx_msg void OnBtnStart();
	afx_msg void OnBtnStop();
	afx_msg void OnBtnPlay();
	afx_msg void OnBtnComb();
	afx_msg void OnClose();
	afx_msg void OnSelchangeComboDevIn();
	afx_msg void OnSelchangeComboDevOut();
	afx_msg void OnSelchangeComboBufSize();
	afx_msg void OnBtnStopPlay();
	afx_msg void OnBtnColors();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	afx_msg LRESULT OnPlayingStoped(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()

private:
	void InitControls();
	void EnableControls(BOOL b);
	WORD GetChannels();
	CString GetAppDir();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WAVRECORDDEMODLG_H__957C49F7_38E9_4A10_B67B_ACF6458F7554__INCLUDED_)
