//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WavRecordDemo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_WAVRECORDDEMO_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDD_COMB_DIALOG                 130
#define IDD_COLOR_DIALOG                131
#define IDC_COMBO_DEV_OUT               1000
#define IDC_COMBO_DEV_IN                1001
#define IDC_RD_MONO                     1002
#define IDC_RD_STEORO                   1003
#define IDC_RD_ALONG                    1004
#define IDC_CHECK_L                     1005
#define IDC_CHECK_R                     1006
#define IDC_COMBO_SF                    1007
#define IDC_COMBO_SB                    1008
#define IDC_COMBO_BUF_SIZE              1009
#define IDC_BTN_START                   1010
#define IDC_BTN_STOP                    1011
#define IDC_BTN_L_FILE                  1011
#define IDC_BTN_PLAY                    1012
#define IDC_BTN_R_FILE                  1012
#define IDC_BTN_COMB                    1013
#define IDC_EDIT1                       1013
#define IDC_BTN_CLR_TEXT                1013
#define IDC_EDIT2                       1014
#define IDC_STATIC_WINDOW               1014
#define IDC_BTN_CLR_SPLIT               1014
#define IDC_BTN_STOP_PLAY               1015
#define IDC_BTN_COLORS                  1016
#define IDC_STATIC_BKGD                 1017
#define IDC_STATIC_WAVE                 1018
#define IDC_STATIC_TEXT                 1019
#define IDC_STATIC_SPLIT                1020
#define IDC_BTN_CLR_BG                  1021
#define IDC_BTN_CLR_WAVE                1022
#define IDC_BTN_COM                     1023
#define IDC_STATIC_TIMER                1024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
