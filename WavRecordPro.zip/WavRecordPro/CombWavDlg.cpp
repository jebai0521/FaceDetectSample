// CombWavDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WavRecordDemo.h"
#include "CombWavDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCombWavDlg dialog


CCombWavDlg::CCombWavDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCombWavDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCombWavDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CCombWavDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCombWavDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCombWavDlg, CDialog)
	//{{AFX_MSG_MAP(CCombWavDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCombWavDlg message handlers

BOOL CCombWavDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CCombWavDlg::MyMessageBox(CString strErr, UINT nType)
{
	switch(nType) 
	{
	case eERR_ERROR:
		MessageBox(strErr, _T("Error"), MB_OK | MB_ICONERROR);
		break;

	case eERR_WARNING:
		MessageBox(strErr, _T("Warning"), MB_OK | MB_ICONWARNING);
		break;

	case eERR_INFO:
		MessageBox(strErr, _T("Info"), MB_OK | MB_ICONINFORMATION);
		break;
	}
}

int CCombWavDlg::CheckValidity(CString strPath, WAVEFORMATEX& wfx)
{
	MMRESULT mmResult = 0;
	DWORD dwFmtSize = 0;
	DWORD dwDataSize = 0;
	HMMIO hWaveFile = NULL;
	MMCKINFO mmckinfoParent;
	MMCKINFO mmckinfoSubChunk;
	LPTSTR pszFilePath = strdup(strPath);

	hWaveFile = mmioOpen(pszFilePath, NULL, MMIO_READ);
	if(hWaveFile == NULL)
	{
		MyMessageBox(_T("Open the wav file failed"), eERR_INFO);
		return -1;
	}

	// Descend 'wave' chunk
	mmckinfoParent.fccType = mmioFOURCC('W','A','V','E');
	mmResult = mmioDescend(hWaveFile, &mmckinfoParent, NULL, MMIO_FINDRIFF);
	if(mmResult)
	{
		MyMessageBox(_T("It is not a wave format file"), eERR_INFO);
		return -1;
	}

	// Desecnd 'fmt ' chunk
	mmckinfoSubChunk.ckid = mmioFOURCC('f', 'm', 't', ' ');
	mmResult = mmioDescend(hWaveFile, &mmckinfoSubChunk, &mmckinfoParent, MMIO_FINDCHUNK);
	if(mmResult)
	{
		MyMessageBox(_T("Can't find the fmt chunk"), eERR_INFO);
		return -1;
	}

	// Read 'fmt ' chunk
	dwFmtSize = mmckinfoSubChunk.cksize;
	if((unsigned long)mmioRead(hWaveFile, (HPSTR)&wfx, dwFmtSize) != dwFmtSize)
	{
		MyMessageBox(_T("Read format chunk failed"), eERR_INFO);
		return -1;
	}
	
	// Ascend the 'fmt ' chunk
	mmResult = mmioAscend(hWaveFile, &mmckinfoSubChunk, 0);
	if(mmResult)
	{
		MyMessageBox(_T("Ascend fmt chunk failed"), eERR_INFO);
		return -1;
	}

	// Descend the 'data' chunk
	mmckinfoSubChunk.ckid = mmioFOURCC('d','a','t','a');
	mmResult = mmioDescend(hWaveFile, &mmckinfoSubChunk, &mmckinfoParent, MMIO_FINDCHUNK);
	if(mmResult)
	{
		MyMessageBox(_T("Cannot find data chunk"), eERR_INFO);
		return -1;
	}
	else
	{
		dwDataSize = mmckinfoSubChunk.cksize;
	}
	
	return dwDataSize;
}

int CCombWavDlg::IsCanCombine(CString strPathL, CString strPathR)
{
	int nCheck1 = 0;
	int nCheck2 = 0;
	WAVEFORMATEX formatL;
	WAVEFORMATEX formatR;

	// Check Validity of the first(left channel) file
	nCheck1 = CheckValidity(strPathL, formatL);
	if(nCheck1 == -1)
	{
		MyMessageBox(_T("Invalid wave file: ") + strPathL, eERR_ERROR);
		return -1;
	}

	// Check Validity of the second(right channel) file
	nCheck2 = CheckValidity(strPathR, formatR);
	if(nCheck2 == -1)
	{
		MyMessageBox(_T("Invalid wave file: ") + strPathR, eERR_ERROR);
		return -1;
	}

	// All of them must be mono wave file
	if(!(formatL.nChannels == 1))
	{
		MyMessageBox(_T("Not a mono wave file: ") + strPathL, eERR_ERROR);
		return -1;
	}
	if(!(formatR.nChannels == 1))
	{
		MyMessageBox(_T("Not a mono wave file: ") + strPathR, eERR_ERROR);
		return -1;
	}

	// They must have the same bps
	if(!(formatL.wBitsPerSample == formatR.wBitsPerSample))
	{
		MyMessageBox(_T("They must have the same bps"), eERR_ERROR);
		return -1;
	}

	// They must have the same sps
	if(formatL.nSamplesPerSec != formatR.nSamplesPerSec)
	{
		MyMessageBox(_T("They must have the same sps"), eERR_ERROR);
		return -1;
	}

	return min(nCheck1, nCheck2);
}

BOOL CCombWavDlg::CreateWaveFile(HMMIO hWaveFile, LPCTSTR lpszFilePath, WAVEFORMATEX wfx)
{
	CString strErr;
	CString strFilePath = lpszFilePath;
	MMCKINFO mmckinfoParent;
	MMCKINFO mmckinfoSubChunk; 
	MMRESULT mmResult = 0;

	if(hWaveFile)
	{
		return TRUE;
	}

	mmioOpen((LPTSTR)lpszFilePath, NULL, MMIO_DELETE); 
	if(hWaveFile)
	{
		return TRUE;
	}
	
	hWaveFile = mmioOpen((LPTSTR)lpszFilePath, 
	                     NULL, 
						 MMIO_CREATE | MMIO_WRITE | MMIO_EXCLUSIVE | MMIO_ALLOCBUF);
	if(!hWaveFile) 
	{
		MyMessageBox(_T("mmioOpen failed"), eERR_ERROR);
		return FALSE;
	}
	
	ZeroMemory(&mmckinfoParent, sizeof(MMCKINFO));
	mmckinfoParent.fccType = mmioFOURCC('W','A','V','E');
	mmResult = mmioCreateChunk(hWaveFile, &mmckinfoParent, MMIO_CREATERIFF);
	if(mmResult)
	{
		MyMessageBox(_T("Create 'WAVE' chunk failed"), eERR_ERROR);
		return FALSE;
	}
	
	ZeroMemory(&mmckinfoSubChunk, sizeof(MMCKINFO));
	mmckinfoSubChunk.ckid = mmioFOURCC('f','m','t',' ');
	mmckinfoSubChunk.cksize = sizeof(WAVEFORMATEX) + wfx.cbSize;
	mmResult = mmioCreateChunk(hWaveFile, &mmckinfoSubChunk, 0);
	if(mmResult)
	{
		MyMessageBox(_T("Create 'fmt' chunk failed"), eERR_ERROR);
		return FALSE;
	}

	long lSize = mmioWrite(hWaveFile, (char*)&wfx, sizeof(WAVEFORMATEX) + wfx.cbSize); 
	if(lSize <= 0)
	{
		MyMessageBox(_T("mmioWrite failed"), eERR_ERROR);
		return FALSE;
	}
	
	mmResult = mmioAscend(hWaveFile, &mmckinfoSubChunk, 0);
	if(mmResult)
	{
		MyMessageBox(_T("mmioAscend failed"), eERR_ERROR);
		return FALSE;
	}
	
	mmckinfoSubChunk.ckid = mmioFOURCC('d', 'a', 't', 'a');
	mmResult = mmioCreateChunk (hWaveFile, &mmckinfoSubChunk, 0);
	if(mmResult)
	{
		MyMessageBox(_T("Create 'data' chunk failed"), eERR_ERROR);
		return FALSE;
	}

	return TRUE;
}

void CCombWavDlg::Combine(CString strPathL, CString strPathR, CString strPathObj)
{
	
}