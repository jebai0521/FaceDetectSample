// WaveRecord.h: interface for the CWaveRecord class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include <mmsystem.h>
#pragma comment(lib, "winmm.lib")

#include <shlwapi.h>
#pragma comment(lib, "shlwapi.lib")

#define QUEUE_BUFFER_SIZE (4096)

class CWaveRecord : public CWnd  
{
public:
	CWaveRecord();
	virtual ~CWaveRecord();

public:
	void Init(HWND hwndParent, LPRECT lpRect, DWORD dwBufferSize, UINT nDeviceID = WAVE_MAPPER); // Init params and graphics window
	BOOL Record(WORD nChs, DWORD nSamplesPerSec, WORD wBitsPerSample); // Start to record
	void StopRecord(); // Stop record
	BOOL IsRecording(){ return m_bRecording; } // Is recording now
	void SaveWaveFormat(WORD nChs, DWORD nSamplesPerSec, WORD wBitsPerSample); // Set parameters of WAVEFORMATEX
	BOOL AllocateMemory(DWORD dwBufferSize); // Allocate memory for record waveform data
	BOOL AddInputBufferToQueue(int nIndex); // Add input buffer to recording queue
	BOOL SaveRecordData2File(LPCTSTR lpszFileName); // Save recorded data to file
	int GetNumDevsIn(){ return waveInGetNumDevs(); }; // Get number of waveform-audio input devices
	void GetProductNames(CStringArray& strArrProductNames); // Get product names of every waveform-audio input devices

	// Callback function used with the waveform-audio input device
	BOOL static CALLBACK waveInProc(HWAVEIN hWaveIn, UINT uMsg, DWORD dwInstance, DWORD dwParam1, DWORD dwParam2);

	// Set and get colors for background, waveform, text and split line
	void SetColors(COLORREF clrBkgd, COLORREF clrWave, COLORREF clrText, COLORREF clrSplit);
	void GetColors(COLORREF& clrBkgd, COLORREF& clrWave, COLORREF& clrText, COLORREF& clrSplit);

private:
	void Close(); // Close the given waveform-audio input device
	void Release(); // Release buffers
	BOOL Create(HWND hWndParent, LPRECT lpRect = NULL); // Create a window for drawing waveform
	BOOL CreateWaveFile(LPCTSTR lpszWaveFileName, UINT nCh); // Create a wave file to save waveform data
	int WriteToFile(PBYTE pByData, DWORD dwSize); // Write recorded data to file
	void StopWriteFile(UINT nCh); // Stop write recorded data to file
	void MyMessageBox(CString strErr, UINT nType); // My message box

	//////////////////////////////////////////////////////////////////////////////////////////
	void DrawWindowBG(CDC *pDC); // Draw background of created window
	CRect GetDrawRect(BOOL bLeft); // Get drawing rect of left or right
	void DrawWave(DWORD dwSize); // Draw waveform 
	void DrwaWave8(CDC *pDC, BYTE *pData, DWORD dwSize, BOOL bLeft); // Draw 8bits waveform
	void DrwaWave16(CDC *pDC, SHORT *pData, DWORD dwSize, BOOL bLeft); // Draw 16bits waveform
	DWORD SplitStereo2Mono(WAVEFORMATEX format, PBYTE pByData, DWORD dwSize); // Split stereo data to mono one

protected:
	HWND m_hParentWnd; // Handle of parent window
	CRect m_rcDrawWnd; // Rect of drawing window
	CPen m_penText; // Pen for text drawing
	CPen m_PenWave; // Pen for waveform drawing
	CPen m_penLine; // Pen for line drawing
	COLORREF m_clrBkgd; // Color of background
	COLORREF m_clrWaveform; // Color of waveform
	COLORREF m_clrText; // Color of text
	COLORREF m_clrSplit; // Color of split line

	////////////////////////////////////////////////////////////////////////////////////////////
	BOOL m_bRecording; // Is recording
	UINT m_nDeviceID; // Identifier of the waveform-audio input device to open
	UINT m_nNumDevsIn; // Number of waveform-audio input devices present in the system	
	HWAVEIN	m_hWaveIn; // Handle an waveform-audio input device
	WORD m_wInQueue; // Number of recording queue
	DWORD m_dwQueBufferSize; // Buffer size of queue
	DWORD m_dwBufNumInQueue; // Number of buffers in queue
	UINT m_nChs; // Channels for recording: mono, stereo or alone
	PBYTE m_pByInDataL; // Pointer point to left channel data
	PBYTE m_pByInDataR; // Pointer point to right channel data
	PBYTE *m_pArrInData; // Pointer point to array of in data
	HMMIO m_hWaveFile[2]; // Handles to an open file
	PWAVEHDR *m_pArrHdr; // Pointer point to array of wave header
	WAVEFORMATEX m_format; // Format of waveform-audio data
	MMCKINFO mmckinfoParent[2]; // RIFF chunk information data structure - Parent
	MMCKINFO mmckinfoSubChunk[2]; // RIFF chunk information data structure - Sub chunk
	WAVEINCAPS m_caps; // Capabilities of a waveform-audio input device

	enum ERR_TYPES
	{
		eERR_ERROR, // MB_OK | MB_ICONERROR
		eERR_WARNING, // MB_OK | MB_ICONWARNING
		eERR_INFO // MB_OK | MB_ICONINFORMATION
	};

public:
	enum REC_CHANNELS
	{
		eCH_MONO, // Mono
		eCH_STEREO, // Stereo
		eCH_ALONE_L, // Alone: left
		eCH_ALONE_R, // Alone: right
		eCH_ALONE_ALL // Alone: left and right
	};

protected:
	//{{AFX_MSG(CWavePlay)
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg LRESULT OnClose(WPARAM wParam, LPARAM lParam);
	//}}AFX_MSG
    LRESULT OnMM_WIM_DATA(WPARAM wParam, LPARAM lParam);
	LRESULT OnMM_WIM_CLOSE(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};
