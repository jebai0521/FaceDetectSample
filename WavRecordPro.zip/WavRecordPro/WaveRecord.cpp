// WaveRecord.cpp: implementation of the CWaveRecord class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "WaveRecord.h"

static CRITICAL_SECTION g_CS;
static BOOL g_bResetting = FALSE; // Is waveoutReset resetting now
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CWaveRecord::CWaveRecord()
{
	Init(NULL, NULL, QUEUE_BUFFER_SIZE);
}

CWaveRecord::~CWaveRecord()
{
	Release();
}

BEGIN_MESSAGE_MAP(CWaveRecord, CWnd)
	//{{AFX_MSG_MAP(CWaveRecord)
	ON_WM_ERASEBKGND()
	ON_WM_TIMER()
	ON_MESSAGE(MM_WIM_DATA,OnMM_WIM_DATA)
	ON_MESSAGE(MM_WIM_CLOSE,OnMM_WIM_CLOSE)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWaveRecord message handlers

BOOL CWaveRecord::OnEraseBkgnd(CDC* pDC) 
{
	DrawWindowBG(pDC);
	return CWnd::OnEraseBkgnd(pDC);
}

void CWaveRecord::MyMessageBox(CString strErr, UINT nType)
{
	switch(nType) 
	{
	case eERR_ERROR:
		MessageBox(strErr, _T("Error"), MB_OK | MB_ICONERROR);
		break;

	case eERR_WARNING:
		MessageBox(strErr, _T("Warning"), MB_OK | MB_ICONWARNING);
		break;

	case eERR_INFO:
		MessageBox(strErr, _T("Info"), MB_OK | MB_ICONINFORMATION);
		break;
	}
}

void CWaveRecord::Init(HWND hwndParent, LPRECT lpRect, DWORD dwBufferSize, UINT nDeviceID /*= WAVE_MAPPER*/)
{
	m_wInQueue = 0;
	m_nNumDevsIn = 0;
	m_dwBufNumInQueue = 0;
	m_hParentWnd = hwndParent;
	m_nDeviceID = WAVE_MAPPER;
	m_dwQueBufferSize = dwBufferSize;
	m_nChs = eCH_STEREO;
	m_hWaveIn = NULL;
	m_pByInDataL = NULL;
	m_pByInDataR = NULL;
	m_bRecording = FALSE;
	m_clrBkgd = RGB(0, 0, 0);
	m_clrWaveform = RGB(75, 243, 167);
	m_clrText = RGB(98, 108, 104);
	m_clrSplit = RGB(0, 53, 0);
	memset(&m_format, 0, sizeof(WAVEFORMATEX));
	ZeroMemory(&mmckinfoParent, sizeof(mmckinfoParent));
	ZeroMemory(&mmckinfoSubChunk, sizeof(mmckinfoSubChunk));
	memset(m_hWaveFile, 0, sizeof(m_hWaveFile));
	InitializeCriticalSection(&g_CS);
	
	if(hwndParent)
	{
		if(!Create(hwndParent, lpRect)) 
		{
			return;
		}
	}
}

void CWaveRecord::Release()
{
	int i = 0;

	for(i = 0; i < 2; i++)
	{
		if(m_hWaveFile[i])
		{
			return;
		}
	}

	if(m_pByInDataL)
	{
		delete []m_pByInDataL;
		m_pByInDataL = NULL;
	}

	if(m_pByInDataR)
	{
		delete []m_pByInDataR;
		m_pByInDataR = NULL;
	}

	if(m_pArrHdr)
	{
		for(int i = 0; i < m_wInQueue; i++)
		{
			if(m_pArrHdr[i])
			{
				delete []m_pArrHdr[i];
			}
		}
		m_pArrHdr = NULL;
	}
	
	if(m_pArrInData)
	{
		for(i = 0; i < m_wInQueue; i++)
		{
			if(m_pArrInData[i])
			{
				delete []m_pArrInData[i];
			}
		}
		m_pArrInData = NULL;
	}	
}

BOOL CWaveRecord::Create(HWND hWndParent, LPRECT lpRect/* = NULL*/)
{
	CRect rc(0, 0, 0, 0);
	rc = *lpRect;

	if(lpRect == NULL || hWndParent == NULL)
	{
		return FALSE;
	}
	
	LPCTSTR lpszClassName = AfxRegisterWndClass(
		0,
		LoadCursor(AfxGetInstanceHandle(), IDC_ARROW),
		NULL, NULL 
		);
	
	if(!CreateEx(0, 
		lpszClassName, 
		_T(""), 
		WS_CHILD | WS_TABSTOP,
		rc.left, 
		rc.top, 
		rc.Width(), 
		rc.Height(), 
		hWndParent, 
		NULL, 
		NULL)
		)
	{
		MyMessageBox(_T("Create window failed"), eERR_ERROR);
		return FALSE;
	}

	if(hWndParent && lpRect)
	{
		m_PenWave.CreatePen(PS_SOLID, 0, m_clrWaveform);
		m_penText.CreatePen(PS_SOLID, 0, m_clrText);
		m_penLine.CreatePen(PS_SOLID, 0, m_clrSplit);
	}

	ShowWindow(SW_SHOW);
	GetClientRect(&m_rcDrawWnd);
	
	return TRUE;
}

CRect CWaveRecord::GetDrawRect(BOOL bLeft)
{
	CRect rcReturn = m_rcDrawWnd;
	
	if(bLeft)
	{
		rcReturn.bottom = m_rcDrawWnd.Height() / 2;
		rcReturn.bottom -= 1;
	}
	else
	{
		rcReturn.top = m_rcDrawWnd.Height() / 2;
		rcReturn.top += 1;
	}
	
	return rcReturn;	
}

void CWaveRecord::DrawWindowBG(CDC *pDC)
{
	int i, nLines = 0;
	const int nGridWidth = 15;
	int nCenterPoint = m_rcDrawWnd.CenterPoint().y;
	
	// Draw background
	CBrush brBkgd;
	brBkgd.CreateSolidBrush(m_clrBkgd);	
	pDC->FillRect(&m_rcDrawWnd, &brBkgd);

	// Draw gridding
	CPen *pOldPen = NULL;
	if(m_penLine.GetSafeHandle())
	{
		pOldPen = pDC->SelectObject(&m_penLine);
	}
	nLines = (nCenterPoint - m_rcDrawWnd.top) / nGridWidth;
	for(i = 1; i <= nLines; i++)
	{
		pDC->MoveTo(m_rcDrawWnd.left, nCenterPoint - i * nGridWidth);
		pDC->LineTo(m_rcDrawWnd.right, nCenterPoint - i * nGridWidth);
	}
	nLines = (m_rcDrawWnd.bottom - nCenterPoint) / nGridWidth;
	for(i = 1; i <= nLines; i++)
	{
		pDC->MoveTo(m_rcDrawWnd.left, nCenterPoint + i * nGridWidth);
		pDC->LineTo(m_rcDrawWnd.right, nCenterPoint + i * nGridWidth);
	}
	nLines = (m_rcDrawWnd.right - m_rcDrawWnd.left) / nGridWidth;
	for(i = 1; i <= nLines; i++)
	{
		pDC->MoveTo(m_rcDrawWnd.left + i * nGridWidth, m_rcDrawWnd.top);
		pDC->LineTo(m_rcDrawWnd.left + i * nGridWidth, m_rcDrawWnd.bottom);
	}
	if(pOldPen) 
	{
		pDC->SelectObject(pOldPen);
	}

	// Draw text of caption
	pDC->SetBkColor(m_clrBkgd);
	pDC->SetTextColor(m_clrText);
	pDC->TextOut(3, 0, _T("L"));
	pDC->TextOut(3, m_rcDrawWnd.bottom - 16, _T("R"));

	// Draw split line
	if(m_penText.GetSafeHandle())
	{
		pOldPen = pDC->SelectObject(&m_penText);
	}
	pDC->MoveTo(0, nCenterPoint);
	pDC->LineTo(m_rcDrawWnd.right, nCenterPoint);
	if(pOldPen) 
	{
		pDC->SelectObject(pOldPen);
	}

	// Draw frame
	pDC->Draw3dRect(&m_rcDrawWnd, RGB(98, 108, 104), RGB(98, 108, 104));
}

DWORD CWaveRecord::SplitStereo2Mono(WAVEFORMATEX format, PBYTE pByData, DWORD dwSize)
{
	DWORD dwStep = 0;
	DWORD dwBytesPerSample = 0;
	
	dwBytesPerSample = format.wBitsPerSample / 8;

	if(!pByData || dwSize == 0)
	{
		return 0;
	}

	if(!m_pByInDataL|| !m_pByInDataR)
	{
		return 0;
	}

	//if(format.nChannels == 1)
	if(m_nChs == eCH_MONO)
	{
		memcpy(m_pByInDataL, pByData, dwSize);
		memcpy(m_pByInDataR, pByData, dwSize);
		return dwSize;
	}
	else
	{
		for(int i = 0; i < dwSize; i += 2 * dwBytesPerSample)
		{
			memcpy(m_pByInDataL + dwStep, pByData + i, dwBytesPerSample);
			memcpy(m_pByInDataR + dwStep, pByData + i + dwBytesPerSample, dwBytesPerSample);
			dwStep += dwBytesPerSample;
		}
		return dwStep;
	}
}

void CWaveRecord::DrawWave(DWORD dwSize)
{
	CClientDC dc(this);

	BOOL bLeft = FALSE;
	BOOL bRight = FALSE;
	CPen *pOldPen = NULL;

	// Case of mono, draw in left rect
	if(m_format.nChannels == 1)
	{
		bLeft = TRUE;
		bRight = FALSE;
	}
	else
	{
		bLeft = TRUE;
		bRight = TRUE;
	}

	// Update background
	DrawWindowBG(&dc);

	if(m_PenWave.GetSafeHandle())
	{
		pOldPen = dc.SelectObject(&m_PenWave);
	}

	if(m_format.wBitsPerSample == 8)
	{
		if(bLeft) 
		{
			DrwaWave8(&dc, (BYTE*)m_pByInDataL, dwSize / 2, TRUE);
		}
		if(bRight) 
		{
			DrwaWave8(&dc, (BYTE*)m_pByInDataR, dwSize / 2, FALSE);
		}
	}
	else
	{
		if(bLeft)
		{
			DrwaWave16(&dc, (short*)m_pByInDataL, dwSize / 2, TRUE);
		}
		if(bRight)
		{
			DrwaWave16(&dc, (short*)m_pByInDataR, dwSize / 2, FALSE);
		}
	}

	if(pOldPen)
	{
		dc.SelectObject(pOldPen);
	}
}

void CWaveRecord::DrwaWave8(CDC *pDC, BYTE *pData, DWORD dwSize, BOOL bLeft)
{
	CRect rcBG = GetDrawRect(bLeft);
	int y = (int)(pData[0] * rcBG.Height() / 0xff);
	
	// Start point
	pDC->MoveTo(0, y);

	// Line one point to another
	float fStep = (float)rcBG.Width() / (float)(dwSize);
	float fPointX = 0;
	for(DWORD i = 1; i < dwSize; i++)
	{
		fPointX += fStep;
		y = (int)(pData[i] * rcBG.Height() / 0xff);
		pDC->LineTo((int)fPointX, y);
	}
}

void CWaveRecord::DrwaWave16(CDC *pDC, SHORT *pData, DWORD dwSize, BOOL bLeft)
{
	CRect rcBG = GetDrawRect(bLeft);
	int nCenterY = rcBG.CenterPoint().y;
	int y = nCenterY + (int)(pData[0] * rcBG.Height() / 0xffff);
	
	// Start point
	pDC->MoveTo (0, y);

	// Line one point to another
	float fStep = (float)rcBG.Width() / (float)(dwSize);
	float fPointX = 0;
	for(DWORD i = 0; i < dwSize; i++)
	{
		fPointX += fStep;
		y = nCenterY + (int)(pData[i] * rcBG.Height() / 0xffff);
		pDC->LineTo((int)fPointX, y);
	}	
}

void CWaveRecord::SetColors(COLORREF clrBkgd, COLORREF clrWave, COLORREF clrText, COLORREF clrSplit)
{
	if(m_PenWave.GetSafeHandle())
	{
		m_PenWave.DeleteObject();
	}
	if(m_penLine.GetSafeHandle())
	{
		m_penLine.DeleteObject();
	}
	m_clrBkgd = clrBkgd;
	m_clrWaveform = clrWave;
	m_clrText = clrText;
	m_clrSplit = clrSplit;
	m_PenWave.CreatePen(PS_SOLID, 0, m_clrWaveform);
	m_penLine.CreatePen(PS_SOLID, 0, m_clrSplit);	
}

void CWaveRecord::GetColors(COLORREF& clrBkgd, COLORREF& clrWave, COLORREF& clrText, COLORREF& clrSplit)
{
	clrBkgd = m_clrBkgd;
	clrWave = m_clrWaveform ;
	clrText = m_clrText;
	clrSplit = m_clrSplit;
}

void CWaveRecord::GetProductNames(CStringArray& strArrProductNames)
{
	WAVEINCAPS caps;
	
	strArrProductNames.RemoveAll();
	for(int i = 0; i < waveInGetNumDevs(); i++)
	{
		waveInGetDevCaps(i, &caps, sizeof(WAVEINCAPS));
		strArrProductNames.Add(caps.szPname);
	}
}

BOOL CWaveRecord::CreateWaveFile(LPCTSTR lpszWaveFileName, UINT nCh)
{
	CString strErr;
	CString strFileName = lpszWaveFileName;
	MMRESULT mmResult = 0;
	WAVEFORMATEX wfx = m_format;

	if(nCh < 0 || nCh >= 2)
	{
		MyMessageBox(_T("The channel is out of range"), eERR_ERROR);
		return FALSE;
	}
	
	if(m_hWaveFile[nCh])
	{
		return TRUE;
	}

	// Truncate file first
	mmioOpen((LPTSTR)lpszWaveFileName, NULL, MMIO_DELETE); 
	
	if(m_nChs == eCH_STEREO)
	{
		wfx.nChannels = 2;
	}
	else
	{
		wfx.nChannels =1;
	}

	m_hWaveFile[nCh] = mmioOpen((LPTSTR)lpszWaveFileName, 
	                            NULL, 
								MMIO_CREATE | MMIO_WRITE | MMIO_EXCLUSIVE | MMIO_ALLOCBUF);
	if(!m_hWaveFile[nCh]) 
	{
		MyMessageBox(_T("mmioOpen failed"), eERR_ERROR);
		return FALSE;
	}
	
	// Create 'wave' format
	ZeroMemory(&mmckinfoParent[nCh], sizeof(MMCKINFO));
	mmckinfoParent[nCh].fccType = mmioFOURCC('W','A','V','E');
	mmResult = mmioCreateChunk(m_hWaveFile[nCh], &mmckinfoParent[nCh], MMIO_CREATERIFF);
	if(mmResult)
	{
		MyMessageBox(_T("Create 'WAVE' chunk failed"), eERR_ERROR);
		return FALSE;
	}
	
	// Create 'fmt ' chunk
	ZeroMemory(&mmckinfoSubChunk[nCh], sizeof(MMCKINFO));
	mmckinfoSubChunk[nCh].ckid = mmioFOURCC('f','m','t',' ');
	mmckinfoSubChunk[nCh].cksize = sizeof(WAVEFORMATEX) + wfx.cbSize;
	mmResult = mmioCreateChunk(m_hWaveFile[nCh], &mmckinfoSubChunk[nCh], 0);
	if(mmResult)
	{
		MyMessageBox(_T("Create 'fmt' chunk failed"), eERR_ERROR);
		return FALSE;
	}

	// Create format chunk
	long lSize = mmioWrite(m_hWaveFile[nCh], (char*)&wfx, sizeof(WAVEFORMATEX) + wfx.cbSize); 
	if(lSize <= 0)
	{
		MyMessageBox(_T("Create format chunk failed"), eERR_ERROR);
		return FALSE;
	}
	
	mmResult = mmioAscend(m_hWaveFile[nCh], &mmckinfoSubChunk[nCh], 0);
	if(mmResult)
	{
		MyMessageBox(_T("mmioAscend failed"), eERR_ERROR);
		return FALSE;
	}
	
	// Crate 'data' chunk
	mmckinfoSubChunk[nCh].ckid = mmioFOURCC('d', 'a', 't', 'a');
	mmResult = mmioCreateChunk(m_hWaveFile[nCh], &mmckinfoSubChunk[nCh], 0);
	if(mmResult)
	{
		MyMessageBox(_T("Create 'data' chunk failed"), eERR_ERROR);
		return FALSE;
	}

	return TRUE;
}

BOOL CWaveRecord::Record(WORD nChs, DWORD nSamplesPerSec, WORD wBitsPerSample)
{
	MMRESULT mmResult = 0;

	if(m_bRecording)
	{
		MyMessageBox(_T("Recording now"), eERR_ERROR);
		return FALSE;
	}

	if((wBitsPerSample % 8))
	{
		MyMessageBox(_T("BPS must be multiple of 8"), eERR_ERROR);
		return FALSE;
	}

	if(wBitsPerSample > 16)
	{
		wBitsPerSample = 16;
	}
	
	SaveWaveFormat(nChs, nSamplesPerSec, wBitsPerSample);

	if(!AllocateMemory(m_dwQueBufferSize))
	{
		MyMessageBox(_T("Allocate memory failed"), eERR_ERROR);
		return FALSE;
	}

	if(m_hParentWnd)
	{
		// Open the given waveform-audio input device for recording
		// Using window callback mechanism
		mmResult = waveInOpen(&m_hWaveIn, 
							  m_nDeviceID, 
							  &m_format, 
						      (DWORD)GetSafeHwnd(), 
						      NULL, 
						      CALLBACK_WINDOW);
	}
	else
	{
		// Using callback function callback mechanism
		mmResult = waveInOpen(&m_hWaveIn, 
							  m_nDeviceID, 
							  &m_format, 
							  (DWORD)waveInProc,
							  (DWORD_PTR)this,
							  CALLBACK_FUNCTION
							  );
	}

	if(mmResult)
	{
		MyMessageBox(_T("waveInOpen failed"), eERR_ERROR);
		Release();
		return FALSE;
	}
	else
	{
		// Add input buffers to the input queue
		for(int i = 0; i< m_wInQueue; i++)
		{
			AddInputBufferToQueue(i);
		}
		
		// Start recording
		mmResult = waveInStart(m_hWaveIn);
		if(mmResult)
		{
			MyMessageBox(_T("waveInStart failed"), eERR_ERROR);
			Release();
			return FALSE;
		}
	}

	m_bRecording = TRUE;
	return TRUE;
}

void CWaveRecord::SaveWaveFormat(WORD nChs, DWORD nSamplesPerSec, WORD wBitsPerSample)
{
	memset(&m_format, 0, sizeof(WAVEFORMATEX));
	
	m_nChs = nChs;
	m_format.cbSize = 0;
	m_format.wFormatTag	= WAVE_FORMAT_PCM;
	m_format.nSamplesPerSec	= nSamplesPerSec;
	m_format.wBitsPerSample	= wBitsPerSample;
	
	if(nChs == eCH_MONO)
	{ 
		m_format.nChannels = 1; 
	}
	else
	{
		m_format.nChannels = 2;
	}
	m_format.nBlockAlign = m_format.nChannels * (m_format.wBitsPerSample / 8);
	m_format.nAvgBytesPerSec = m_format.nSamplesPerSec * m_format.nBlockAlign;
}

BOOL CWaveRecord::AllocateMemory(DWORD dwBufferSize)
{
	Release();

	m_wInQueue = (m_format.nChannels + 
		          m_format.wBitsPerSample / 8 + 
				  m_format.nSamplesPerSec / 11025);

	if(m_wInQueue <= 0)
	{
		return FALSE;
	}
	
	m_pArrInData = new BYTE*[m_wInQueue];
	m_pArrHdr = new WAVEHDR*[m_wInQueue];
	if(!m_pArrInData || !m_pArrHdr)
	{
		return FALSE;
	}
	else
	{
		memset(m_pArrInData, 0, sizeof(BYTE*) * m_wInQueue);
		memset(m_pArrHdr, 0, sizeof(WAVEHDR*) * m_wInQueue);
	}

	if(m_hParentWnd)
	{
		m_pByInDataL = new BYTE[m_dwQueBufferSize];
		m_pByInDataR = new BYTE[m_dwQueBufferSize];
		if(!m_pByInDataL || !m_pByInDataR)
		{
			return FALSE;
		}
		else
		{
			memset(m_pByInDataL, 0, sizeof(BYTE) * m_dwQueBufferSize);
			memset(m_pByInDataR, 0, sizeof(BYTE) * m_dwQueBufferSize);
		}
	}

	for(int i = 0; i < m_wInQueue; i++)
	{
		m_pArrInData[i] = new BYTE[m_dwQueBufferSize];
		m_pArrHdr[i] = new WAVEHDR;
		if(!m_pArrInData[i] || !m_pArrHdr[i])
		{
			return FALSE;
		}
		memset(m_pArrInData[i], 0, m_dwQueBufferSize);
		memset(m_pArrHdr[i], 0, sizeof(WAVEHDR));
	}
	
	return TRUE;
}

BOOL CWaveRecord::AddInputBufferToQueue(int nIndex)
{
	MMRESULT mmResult = 0;

	if(nIndex < 0 || nIndex >= m_wInQueue)
	{
		return FALSE;
	}

	if(!m_pArrInData[nIndex])
	{
		return FALSE;
	}
	
	LPWAVEHDR pHdr = m_pArrHdr[nIndex];
	ZeroMemory(pHdr, sizeof(WAVEHDR));
	pHdr->lpData = (char*)m_pArrInData[nIndex];
	pHdr->dwBufferLength = m_dwQueBufferSize;
	
	// Prepares a buffer for waveform-audio input
	mmResult = waveInPrepareHeader(m_hWaveIn, pHdr, sizeof(WAVEHDR));
	if(mmResult)
	{
		MyMessageBox(_T("waveInPrepareHeader Failed"), eERR_ERROR);
		return false;
	}
	
	// Send an input buffer to the given waveform-audio input device
	mmResult = waveInAddBuffer(m_hWaveIn, pHdr, sizeof(WAVEHDR));
	if(mmResult)
	{
		MyMessageBox(_T("waveInAddBuffer failed"), eERR_ERROR);
		return false;
	}

	m_dwBufNumInQueue++;
	return TRUE;
}

BOOL CWaveRecord::SaveRecordData2File(LPCTSTR lpszFileName)
{
	int nDot = 0; 
	int nLen = 0;
	CString strFileName = lpszFileName;
	CString strFileNameL, strFileNameR;

	nDot = strFileName.Find(_T('.'));
	if(nDot == -1)
	{
		return FALSE;
	}
	else
	{
		nLen = strFileName.GetLength();
		strFileNameL = strFileName.Left(nDot) + _T("_L.wav");
		strFileNameR = strFileName.Left(nDot) + _T("_R.wav");
	}
	
	if(m_nChs == eCH_ALONE_ALL)
	{
		if(!CreateWaveFile(strFileNameL, 0))
		{
			StopWriteFile(0);
			return FALSE;
		}

		if(!CreateWaveFile(strFileNameR, 1))
		{
			StopWriteFile(1);
			return FALSE;
		}
	}
	else if(m_nChs == eCH_ALONE_L)
	{
		if(!CreateWaveFile(strFileNameL, 0))
		{
			StopWriteFile(0);
			return FALSE;
		}
	}
	else if(m_nChs == eCH_ALONE_R)
	{
		if(!CreateWaveFile(strFileNameR, 1))
		{
			StopWriteFile(1);
			return FALSE;
		}
	}
	else
	{
		if(!CreateWaveFile(strFileName, 0))
		{
			StopWriteFile(0);
			return FALSE;
		}
	}
	
	return TRUE;
}

int CWaveRecord::WriteToFile(PBYTE pByData, DWORD dwSize)
{
	int nPickup = SplitStereo2Mono(m_format, pByData, dwSize);
	int nRecBytes[2] = {dwSize, dwSize};
	char* pRecData[2] = {(char*)pByData, (char*)pByData};	
	
	if(m_nChs != eCH_MONO && m_nChs != eCH_STEREO)
	{
		pRecData[0] = (char*)m_pByInDataL;
		pRecData[1] = (char*)m_pByInDataR;
		nRecBytes[0] = nPickup;
		nRecBytes[1] = nPickup;
	}
	
	for(int nCh = 0; nCh < 2; nCh++)
	{
		if(m_hWaveFile[nCh])
		{
			int length = mmioWrite(m_hWaveFile[nCh], pRecData[nCh], nRecBytes[nCh]);
			if(nRecBytes[nCh] != length)
			{
				m_dwBufNumInQueue--;
				StopRecord();
				return -1;
			}
		}
	}

	return nPickup;
}	

void CWaveRecord::StopWriteFile(UINT nCh)
{
	// Call mmioAscend function to mark the end of the chunk
	// And mmioAscend will corrects the chunk size
	if(m_hWaveFile[nCh])
	{	
		mmioAscend(m_hWaveFile[nCh], &mmckinfoParent[nCh], 0);
		mmioAscend(m_hWaveFile[nCh], &mmckinfoSubChunk[nCh], 0);
		mmioClose(m_hWaveFile[nCh], 0);
		m_hWaveFile[nCh] = NULL;
	}
}

void CWaveRecord::StopRecord()
{
	MMRESULT mmResult = 0;

	if(!m_hWaveIn)
	{
		return;
	}
	
	if(!m_bRecording)
	{
		return;
	}
	
	EnterCriticalSection(&g_CS);
	g_bResetting = TRUE;
	LeaveCriticalSection(&g_CS);

	mmResult = waveInReset(m_hWaveIn);
	if(mmResult)
	{
		MyMessageBox(_T("waveInReset failed"), eERR_ERROR);
		return;
	}
	g_bResetting = FALSE;
	
	mmResult = waveInClose(m_hWaveIn);
	if(mmResult) 
	{
		MyMessageBox(_T("waveInClose failed"), eERR_ERROR);	
		return;
	}

	for(int nCh = 0; nCh < 2; nCh++)
	{
		StopWriteFile(nCh);
	}
	
	m_bRecording = FALSE;
	
	if(m_hParentWnd)
	{
		CDC *pDC = GetDC();
		DrawWindowBG(pDC);
	}
}

void CWaveRecord::OnTimer(UINT nIDEvent) 
{	
	CWnd::OnTimer(nIDEvent);
}

LRESULT CWaveRecord::OnMM_WIM_CLOSE(WPARAM wParam, LPARAM lParam)
{
	return 0L;
}

LRESULT CWaveRecord::OnMM_WIM_DATA(WPARAM wParam, LPARAM lParam)
{
	int nPickup = 0;
	MMRESULT mmResult = 0;
	LPWAVEHDR pHdr = (LPWAVEHDR)lParam;

	if(!m_bRecording)
	{
		return 0L;
	}

	mmResult = waveInUnprepareHeader(m_hWaveIn, pHdr, sizeof(WAVEHDR));
	if(mmResult)
	{
		MyMessageBox(_T("waveInUnprepareHeader failed"), eERR_ERROR);
		return -1L;
	}

	if(m_bRecording)
	{	
		nPickup = WriteToFile((PBYTE)pHdr->lpData, pHdr->dwBytesRecorded);
		if(nPickup == -1)
		{
			MyMessageBox(_T("Write file failed"), eERR_ERROR);
			return FALSE;
		}

		// Prepares a buffer for waveform-audio input
		mmResult = waveInPrepareHeader(m_hWaveIn, pHdr, sizeof(WAVEHDR));
		if(mmResult)
		{
			MyMessageBox(_T("waveInPrepareHeader failed"), eERR_ERROR);
			return -1L;
		}
		else
		{
			mmResult = waveInAddBuffer(m_hWaveIn, pHdr, sizeof(WAVEHDR));
			if(mmResult)
			{
				MyMessageBox(_T("waveInAddBuffer failed"), eERR_ERROR);
				return -1L;
			}
			else
			{
				if(m_hParentWnd)
				{
					DrawWave((DWORD)nPickup);
				}
			}
		}
	}
	else
	{
		if(m_dwBufNumInQueue <= 1)
		{
			StopRecord();
		}
		else
		{
			m_dwBufNumInQueue--;
		}
	}
	
	return 0L;
}

BOOL CWaveRecord::waveInProc(HWAVEIN hWaveIn, UINT uMsg, DWORD dwInstance, DWORD dwParam1, DWORD dwParam2)
{
	int nPickup = 0;
	BOOL bResult = TRUE;
	MMRESULT mmResult = 0;
	LPWAVEHDR pHdr = (LPWAVEHDR)dwParam1;
	CWaveRecord* pWaveRecord = (CWaveRecord*)dwInstance;

	if(!pWaveRecord->m_bRecording)
	{
		return TRUE;
	}

	EnterCriticalSection(&g_CS);

	switch(uMsg)
	{
	case WIM_OPEN: break;

	case WIM_CLOSE: break;

	case WIM_DATA:
		if(!g_bResetting)
		{
			mmResult = waveInUnprepareHeader(hWaveIn, pHdr, sizeof(WAVEHDR));
			if(mmResult)
			{
				bResult = FALSE;
				pWaveRecord->MyMessageBox(_T("waveInUnprepareHeader failed"), eERR_ERROR);
			}

			if(pWaveRecord->m_bRecording)
			{	
				nPickup = pWaveRecord->WriteToFile((PBYTE)pHdr->lpData, pHdr->dwBytesRecorded);
				if(nPickup == -1)
				{
					bResult = FALSE;
					pWaveRecord->MyMessageBox(_T("Write to file failed"), eERR_ERROR);
				}
		
				// Prepares a buffer for waveform-audio input
				mmResult = waveInPrepareHeader(pWaveRecord->m_hWaveIn, pHdr, sizeof(WAVEHDR));
				if(mmResult)
				{
					bResult = FALSE;
					pWaveRecord->MyMessageBox(_T("waveInPrepareHeader failed"), eERR_ERROR);
				}
				else
				{
					mmResult = waveInAddBuffer(pWaveRecord->m_hWaveIn, pHdr, sizeof(WAVEHDR));
					if(mmResult)
					{
						bResult = FALSE;
						pWaveRecord->MyMessageBox(_T("waveInAddBuffer failed"), eERR_ERROR);
					}
					else
					{
						if(pWaveRecord->m_hParentWnd)
						{
							pWaveRecord->DrawWave(nPickup);
						}
					}
				}
			}
		}
	}

	LeaveCriticalSection(&g_CS);

	return TRUE;
}