// ColorDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WavRecordDemo.h"
#include "ColorDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CColorDlg dialog


CColorDlg::CColorDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CColorDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CColorDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CColorDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CColorDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CColorDlg, CDialog)
	//{{AFX_MSG_MAP(CColorDlg)
	ON_BN_CLICKED(IDC_BTN_CLR_BG, OnBtnClrBg)
	ON_BN_CLICKED(IDC_BTN_CLR_WAVE, OnBtnClrWave)
	ON_BN_CLICKED(IDC_BTN_CLR_TEXT, OnBtnClrText)
	ON_BN_CLICKED(IDC_BTN_CLR_SPLIT, OnBtnClrSplit)
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CColorDlg message handlers

void CColorDlg::OnBtnClrBg() 
{
	CColorDialog clrDlg;
	if(clrDlg.DoModal() == IDOK)
	{
		m_clrBkgd = clrDlg.GetColor();
	}
}

void CColorDlg::OnBtnClrWave() 
{
	CColorDialog clrDlg;
	if(clrDlg.DoModal() == IDOK)
	{
		m_clrWaveform = clrDlg.GetColor();
	}
}

void CColorDlg::OnBtnClrText() 
{
	CColorDialog clrDlg;
	if(clrDlg.DoModal() == IDOK)
	{
		m_clrText = clrDlg.GetColor();
	}
}

void CColorDlg::OnBtnClrSplit() 
{
	CColorDialog clrDlg;
	if(clrDlg.DoModal() == IDOK)
	{
		m_clrSplit = clrDlg.GetColor();
	}
}

HBRUSH CColorDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	switch(pWnd->GetDlgCtrlID())
	{
		case IDC_STATIC_BKGD:
			pDC->SetTextColor(m_clrBkgd);
			break;
		
		case IDC_STATIC_WAVE:
			pDC->SetTextColor(m_clrWaveform);
			break;

		case IDC_STATIC_TEXT:
			pDC->SetTextColor(m_clrText);
			break;

		case IDC_STATIC_SPLIT:
			pDC->SetTextColor(m_clrSplit);
			break;
	}

	return hbr;
}
