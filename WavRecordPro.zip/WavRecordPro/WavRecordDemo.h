// WavRecordDemo.h : main header file for the WAVRECORDDEMO application
//

#if !defined(AFX_WAVRECORDDEMO_H__90E64897_544D_48E7_9E51_D26E658D4CB2__INCLUDED_)
#define AFX_WAVRECORDDEMO_H__90E64897_544D_48E7_9E51_D26E658D4CB2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CWavRecordDemoApp:
// See WavRecordDemo.cpp for the implementation of this class
//

class CWavRecordDemoApp : public CWinApp
{
public:
	CWavRecordDemoApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWavRecordDemoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CWavRecordDemoApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WAVRECORDDEMO_H__90E64897_544D_48E7_9E51_D26E658D4CB2__INCLUDED_)
