// WavePlay.cpp: implementation of the CCWavePlayer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "WavePlay.h"
#include "math.h"

static CRITICAL_SECTION g_CS;
static BOOL g_bResetting = FALSE; // Is waveoutReset resetting now
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CWavePlay::CWavePlay()
{
	Init(NULL, NULL, QUEUE_BUFFER_SIZE);
}

CWavePlay::~CWavePlay()
{
	Stop();
	Release(); // Release buffers

	if(m_PenWave.GetSafeHandle())
	{
		m_PenWave.DeleteObject();
	}
	if(m_penText.GetSafeHandle())
	{
		m_penText.DeleteObject();
	}
	if(m_penLine.GetSafeHandle())
	{
		m_penLine.DeleteObject();
	}
}

BEGIN_MESSAGE_MAP(CWavePlay, CWnd)
	//{{AFX_MSG_MAP(CWavePlay)
	ON_WM_ERASEBKGND()
	ON_MESSAGE(WM_USER_CLOSE, OnClose)
	ON_MESSAGE(MM_WOM_DONE,OnMM_WOM_DONE)
	ON_MESSAGE(MM_WOM_CLOSE,OnMM_WOM_CLOSE)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWavePlayer message handlers

BOOL CWavePlay::OnEraseBkgnd(CDC* pDC) 
{
	DrawWindowBG(pDC);
	return CWnd::OnEraseBkgnd(pDC);
}

void CWavePlay::Init(HWND hwndParent, LPRECT lpRect, DWORD dwBufferSize, UINT nDeviceID /*=WAVE_MAPPER*/)
{
	m_pArrHdr = NULL;
	m_pArrOutData = NULL;
	m_bPaused = FALSE;
	m_bPlaying = FALSE;
	m_nDeviceID = nDeviceID;
	m_dwFmtSize = 0;
	m_dwDataSize = 0;
	m_dwBufferNumInQueue = 0;
	m_nStep1 = 0;
	m_nStep2 = 0;
	m_nInitPos = 0;
	m_nRangeMax = 0;
	m_nStepCount = 0;
	m_dwReadDataCount = 0;
	m_hParentWnd = hwndParent;
	m_dwQueBufferSize = dwBufferSize;
	m_pByOutDataL = NULL;
	m_pByOutDataR = NULL;
	m_hWaveOut = NULL;
	m_hWaveFile = NULL;
	m_clrBkgd = RGB(0, 0, 0);
	m_clrWaveform = RGB(75, 243, 167);
	m_clrText = RGB(98, 108, 104);
	m_clrSplit = RGB(0, 53, 0);
	memset(&m_format, 0, sizeof(WAVEFORMATEX));
	memset(&m_caps, 0, sizeof(WAVEOUTCAPS));
	ZeroMemory(&m_mmckinfoParent, sizeof(MMCKINFO));
	ZeroMemory(&m_mmckinfoSubChunk, sizeof(MMCKINFO));
	Create(hwndParent, lpRect);  // Create window or draw waveform
	InitializeCriticalSection(&g_CS);
}

BOOL CWavePlay::Create(HWND hWndParent, LPRECT lpRect/* = NULL*/)
{
	CRect rc(0, 0, 0, 0);
	rc = *lpRect;

	if(lpRect == NULL || hWndParent == NULL)
	{
		return FALSE;
	}

	LPCTSTR lpszClassName = AfxRegisterWndClass(
		0,
		LoadCursor(AfxGetInstanceHandle(), IDC_ARROW),
		NULL, NULL 
		);
	
	if(!CreateEx(0, 
		lpszClassName, 
		_T(""), 
		WS_CHILD | WS_TABSTOP,
		rc.left, 
		rc.top, 
		rc.Width(), 
		rc.Height(), 
		hWndParent, 
		NULL, 
		NULL)
		)
	{
		MyMessageBox(_T("Create window failed"), eERR_ERROR);
		return FALSE;
	}

	if(hWndParent && lpRect)
	{
		m_PenWave.CreatePen(PS_SOLID, 0, m_clrWaveform);
		m_penText.CreatePen(PS_SOLID, 0, m_clrText);
		m_penLine.CreatePen(PS_SOLID, 0, m_clrSplit);
	}

	ShowWindow(SW_SHOW);
	GetClientRect(&m_rcDrawWnd);

	return TRUE;
}

CRect CWavePlay::GetDrawRect(BOOL bLeft)
{
	CRect rcReturn = m_rcDrawWnd;
	
	if(bLeft)
	{
		rcReturn.bottom = m_rcDrawWnd.Height() / 2;
		rcReturn.bottom -= 1;
	}
	else
	{
		rcReturn.top = m_rcDrawWnd.Height() / 2;
		rcReturn.top += 1;
	}
	
	return rcReturn;	
}

void CWavePlay::SetColors(COLORREF clrBkgd, COLORREF clrWave, COLORREF clrText, COLORREF clrSplit)
{
	if(m_PenWave.GetSafeHandle())
	{
		m_PenWave.DeleteObject();
	}
	if(m_penLine.GetSafeHandle())
	{
		m_penLine.DeleteObject();
	}
	m_clrBkgd = clrBkgd;
	m_clrWaveform = clrWave;
	m_clrText = clrText;
	m_clrSplit = clrSplit;
	m_PenWave.CreatePen(PS_SOLID, 0, m_clrWaveform);
	m_penLine.CreatePen(PS_SOLID, 0, m_clrSplit);
	Invalidate();
}

void CWavePlay::GetColors(COLORREF& clrBkgd, COLORREF& clrWave, COLORREF& clrText, COLORREF& clrSplit)
{
	clrBkgd = m_clrBkgd;
	clrWave = m_clrWaveform ;
	clrText = m_clrText;
	clrSplit = m_clrSplit;
}

void CWavePlay::DrawWindowBG(CDC *pDC)
{
	int i, nLines = 0;
	const int nGridWidth = 15;
	int nCenterPoint = m_rcDrawWnd.CenterPoint().y;
	
	// Draw background
	CBrush brBkgd;
	brBkgd.CreateSolidBrush(m_clrBkgd);	
	pDC->FillRect(&m_rcDrawWnd, &brBkgd);

	// Draw gridding lines
	CPen *pOldPen = NULL;
	if(m_penLine.GetSafeHandle())
	{
		pOldPen = pDC->SelectObject(&m_penLine);
	}
	nLines = (nCenterPoint - m_rcDrawWnd.top) / nGridWidth;
	for(i = 1; i <= nLines; i++)
	{
		pDC->MoveTo(m_rcDrawWnd.left, nCenterPoint - i * nGridWidth);
		pDC->LineTo(m_rcDrawWnd.right, nCenterPoint - i * nGridWidth);
	}
	nLines = (m_rcDrawWnd.bottom - nCenterPoint) / nGridWidth;
	for(i = 1; i <= nLines; i++)
	{
		pDC->MoveTo(m_rcDrawWnd.left, nCenterPoint + i * nGridWidth);
		pDC->LineTo(m_rcDrawWnd.right, nCenterPoint + i * nGridWidth);
	}
	nLines = (m_rcDrawWnd.right - m_rcDrawWnd.left) / nGridWidth;
	for(i = 1; i <= nLines; i++)
	{
		pDC->MoveTo(m_rcDrawWnd.left + i * nGridWidth, m_rcDrawWnd.top);
		pDC->LineTo(m_rcDrawWnd.left + i * nGridWidth, m_rcDrawWnd.bottom);
	}
	if(pOldPen) 
	{
		pDC->SelectObject(pOldPen);
	}

	// Draw text of caption
	pDC->SetBkColor(m_clrBkgd);
	pDC->SetTextColor(m_clrText);
	pDC->TextOut(3, 0, _T("L"));
	pDC->TextOut(3, m_rcDrawWnd.bottom - 16, _T("R"));

	// Draw split line
	if(m_penText.GetSafeHandle())
	{
		pOldPen = pDC->SelectObject(&m_penText);
	}
	pDC->MoveTo(0, nCenterPoint);
	pDC->LineTo(m_rcDrawWnd.right, nCenterPoint);
	if(pOldPen) 
	{
		pDC->SelectObject(pOldPen);
	}

	// Draw frame
	pDC->Draw3dRect(&m_rcDrawWnd, RGB(98, 108, 104), RGB(98, 108, 104));
}

DWORD CWavePlay::SplitStereo2Mono(WAVEFORMATEX format, PBYTE pByData, DWORD dwSize)
{
	DWORD dwStep = 0;
	DWORD dwBytesPerSample = 0;
	
	dwBytesPerSample = format.wBitsPerSample / 8;

	if(!pByData || dwSize == 0)
	{
		return 0;
	}

	if(!m_pByOutDataL || !m_pByOutDataR)
	{
		return 0;
	}

	if(format.nChannels == 1)
	{
		memcpy(m_pByOutDataL, pByData, dwSize);
		memcpy(m_pByOutDataR, pByData, dwSize);
		return dwSize;
	}
	else
	{
		for(int i = 0; i < dwSize; i += 2 * dwBytesPerSample)
		{
			memcpy(m_pByOutDataL + dwStep, pByData + i, dwBytesPerSample);
			memcpy(m_pByOutDataR + dwStep, pByData + i + dwBytesPerSample, dwBytesPerSample);
			dwStep += dwBytesPerSample;
		}
		return dwStep;
	}
}

void CWavePlay::DrawWave(DWORD dwSize)
{
	CClientDC dc(this);

	BOOL bLeft = FALSE;
	BOOL bRight = FALSE;
	CPen *pOldPen = NULL;

	// Case of mono, draw in left rect
	if(m_format.nChannels == 1)
	{
		bLeft = TRUE;
		bRight = FALSE;
	}
	else
	{
		bLeft = TRUE;
		bRight = TRUE;
	}

	// Update background
	DrawWindowBG(&dc);

	if(m_PenWave.GetSafeHandle())
	{
		pOldPen = dc.SelectObject(&m_PenWave);
	}

	if(m_format.wBitsPerSample == 8)
	{
		if(bLeft) 
		{
			DrwaWave8(&dc, (BYTE*)m_pByOutDataL, dwSize / 2, TRUE);
		}
		if(bRight) 
		{
			DrwaWave8(&dc, (BYTE*)m_pByOutDataR, dwSize / 2, FALSE);
		}
	}
	else
	{
		if(bLeft)
		{
			DrwaWave16(&dc, (short*)m_pByOutDataL, dwSize / 2, TRUE);
		}
		if(bRight)
		{
			DrwaWave16(&dc, (short*)m_pByOutDataR, dwSize / 2, FALSE);
		}
	}

	if(pOldPen)
	{
		dc.SelectObject(pOldPen);
	}
}

void CWavePlay::DrwaWave8(CDC *pDC, BYTE *pData, DWORD dwSize, BOOL bLeft)
{
	CRect rcBG = GetDrawRect(bLeft);
	int y = (int)(pData[0] * rcBG.Height() / 0xff);
	
	// Start point
	pDC->MoveTo(0, y);

	// Line one point to another
	float fStep = (float)rcBG.Width() / (float)(dwSize);
	float fPointX = 0;
	for(DWORD i = 1; i < dwSize; i++)
	{
		fPointX += fStep;
		y = (int)(pData[i] * rcBG.Height() / 0xff);
		pDC->LineTo((int)fPointX, y);
	}
}

void CWavePlay::DrwaWave16(CDC *pDC, SHORT *pData, DWORD dwSize, BOOL bLeft)
{
	CRect rcBG = GetDrawRect(bLeft);
	int nCenterY = rcBG.CenterPoint().y;
	int y = nCenterY + (int)(pData[0] * rcBG.Height() / 0xffff);
	
	// Start point
	pDC->MoveTo (0, y);
	
	// Line one point to another
	float fStep = (float)rcBG.Width() / (float)(dwSize);
	float fPointX = 0;
	for(DWORD i = 0; i < dwSize; i++)
	{
		fPointX += fStep;
		y = nCenterY + (int)(pData[i] * rcBG.Height() / 0xffff);
		pDC->LineTo((int)fPointX, y);
	}	
}

void CWavePlay::Release()
{
	int i = 0;

	if(m_pArrOutData)
	{
		for(i = 0; i < m_dwQueue; i++)
		{
			if(m_pArrOutData[i])
			{
				delete []m_pArrOutData[i];
			}
		}
		delete []m_pArrOutData;
	}

	if(m_pArrHdr)
	{
		for(i = 0; i < m_dwQueue; i++)
		{
			if(m_pArrHdr[i]) 
			{
				delete []m_pArrHdr[i];
			}
		}
		delete []m_pArrHdr;
	}
	
	if(m_pByOutDataL) delete []m_pByOutDataL;
	if(m_pByOutDataR) delete []m_pByOutDataR;

	m_pArrHdr = NULL;
	m_pArrOutData = NULL;
	m_pByOutDataL = NULL;
	m_pByOutDataR = NULL;
}

void CWavePlay::MyMessageBox(CString strErr, UINT nType)
{
	switch(nType) 
	{
	case eERR_ERROR:
		MessageBox(strErr, _T("Error"), MB_OK | MB_ICONERROR);
		break;

	case eERR_WARNING:
		MessageBox(strErr, _T("Warning"), MB_OK | MB_ICONWARNING);
		break;

	case eERR_INFO:
		MessageBox(strErr, _T("Info"), MB_OK | MB_ICONINFORMATION);
		break;
	}
}

BOOL CWavePlay::CheckValidity(CString strFilePath)
{
	MMRESULT mmResult = 0;
	LPTSTR pszFilePath = strdup(strFilePath);

	m_hWaveFile = mmioOpen(pszFilePath, NULL, MMIO_READ);
	if(m_hWaveFile == NULL)
	{
		MyMessageBox(_T("Open the wav file failed"), eERR_INFO);
		return FALSE;
	}

	// Descend 'wave' chunk
	m_mmckinfoParent.fccType = mmioFOURCC('W','A','V','E');
	mmResult = mmioDescend(m_hWaveFile, &m_mmckinfoParent, NULL, MMIO_FINDRIFF);
	if(mmResult)
	{
		MyMessageBox(_T("It is not a wave format file"), eERR_INFO);
		return FALSE;
	}

	// Descend 'fmt ' chunk
	m_mmckinfoSubChunk.ckid = mmioFOURCC('f', 'm', 't', ' ');
	mmResult = mmioDescend(m_hWaveFile, &m_mmckinfoSubChunk, &m_mmckinfoParent, MMIO_FINDCHUNK);
	if(mmResult)
	{
		MyMessageBox(_T("Can't find the fmt chunk"), eERR_INFO);
		return FALSE;
	}

	// Read 'fmt ' chunk
	m_dwFmtSize = m_mmckinfoSubChunk.cksize;
	if((unsigned long)mmioRead(m_hWaveFile, (HPSTR)&m_format, m_dwFmtSize) != m_dwFmtSize)
	{
		MyMessageBox(_T("Read format chunk failed"), eERR_INFO);
		return FALSE;
	}
	
	// Ascend the 'fmt ' chunk
	mmResult = mmioAscend(m_hWaveFile, &m_mmckinfoSubChunk, 0);
	if(mmResult)
	{
		MyMessageBox(_T("Ascend fmt chunk failed"), eERR_INFO);
		return FALSE;
	}

	// Descend the 'data' chunk
	m_mmckinfoSubChunk.ckid = mmioFOURCC('d','a','t','a');
	mmResult = mmioDescend(m_hWaveFile, &m_mmckinfoSubChunk, &m_mmckinfoParent, MMIO_FINDCHUNK);
	if(mmResult)
	{
		MyMessageBox(_T("Cannot find data chunk"), eERR_INFO);
		return FALSE;
	}
	else
	{
		// Point to the start position of wave data
		m_dwDataSize = m_mmckinfoSubChunk.cksize;
		m_nInitPos = mmioSeek(m_hWaveFile, 0, SEEK_CUR);
	}
	
	return TRUE;
}

void CWavePlay::CalcForProgess()
{
	int n100 = 100, nCoef = 1;

	m_nStepCount = 0;
	if(m_dwDataSize < m_dwQueBufferSize)
	{
		m_dwQueue = 1;
		m_dwQueBufferSize = m_dwDataSize;
	}
	m_nStep1 = m_dwDataSize / m_dwQueBufferSize;

	while(TRUE) 
	{
		if(m_nStep1 >= 0 && m_nStep1 < n100)
		{
			m_nRangeMax = m_nStep1;
			break;
		}
		if(m_nStep1 >= n100 && m_nStep1 < 5*n100*nCoef)
		{
			m_nRangeMax = m_nStep1 / (5*nCoef);
			break;
		}
		nCoef = pow((long double)2, nCoef);
	}
	m_nStep2 = m_nStep1/m_nRangeMax;
}

BOOL CWavePlay::Open(CString strFilePath)
{
	BOOL b = FALSE;
	MMRESULT mmResult = 0;

	// If file path not exist
	if(!PathFileExists(const_cast<LPCSTR>((LPCTSTR)strFilePath)))
	{
		return FALSE;
	}
	
	// Check the validity of wave file
    b = CheckValidity(strFilePath);
	if(!b)
	{
		MyMessageBox(_T("Invalid wav file"), eERR_ERROR);
		return FALSE;
	}

	// Get the capabilities of a given waveform-audio output device
	mmResult = waveOutGetDevCaps(m_nDeviceID, &m_caps, sizeof(m_caps));
	if(mmResult)
	{
		MyMessageBox(_T("waveOutGetDevCaps failed"), eERR_ERROR);
		return FALSE;
	}
	else
	{
		// Case of invalid format
		if(m_caps.dwFormats == WAVE_INVALIDFORMAT)
		{
			// The driver should indicate whether or not it supports the specified format
			mmResult = waveOutOpen(&m_hWaveOut, 
				                   m_nDeviceID, 
				                   &m_format, 
				                   NULL,
				                   NULL,
				                   WAVE_FORMAT_QUERY
				                   );
			if(mmResult)
			{
				MyMessageBox(_T("Not supported wave format"), eERR_ERROR);
				return FALSE;
			}
		}
	}

	// Calculate params for progress slider
	CalcForProgess();

	// Allocate memory for array of output data and wave header
	b = AllocateMemory(m_dwQueBufferSize);
	if(!b)
	{
		MyMessageBox(_T("Allocate memory failed"), eERR_ERROR);
		return FALSE;
	}

	if(m_hParentWnd)
	{
		// Open the given waveform-audio output device for playback
		// Using window callback mechanism
		mmResult = waveOutOpen(&m_hWaveOut, 
							   m_nDeviceID, 
							   &m_format, 
							   (DWORD)GetSafeHwnd(),
							   NULL,
							   CALLBACK_WINDOW
							   );
	}
	else
	{
		// Using callback function callback mechanism
		mmResult = waveOutOpen(&m_hWaveOut, 
							   m_nDeviceID, 
							   &m_format, 
							   (DWORD)waveOutProc,
							   (DWORD_PTR)this,
							   CALLBACK_FUNCTION
							   );
	}
	if(mmResult)
	{
		MyMessageBox(_T("waveOutOpen failed"), eERR_ERROR);
		return FALSE;
	}

	return TRUE;
}

void CWavePlay::Play(CString strFilePath)
{
	BOOL b = FALSE;
	MMRESULT mmResult = 0;

	// If is playing now
	if(m_bPlaying)
	{
		return;
	}

	// If paused then restart
	else if(m_bPaused)
	{
		Restart();
		return;
	}
	else
	{		
		if(!Open(strFilePath))
		{
			return;
		}
		
		m_bPaused = FALSE;
		m_bPlaying = TRUE;
		m_dwReadDataCount = 0;

		// Fill buffers with sound data for every queues
		for(int i = 0; i < m_dwQueue; i++)
		{
			int nSize = m_dwQueBufferSize;
			if(ReadSoundDataFromFile(m_pArrOutData[i], nSize))
			{
				if(!AddOutputBufferToQueue(i, nSize))
				{
					MyMessageBox(_T("Add output buffer to queue failed"), eERR_ERROR);
					return;
				}
			}
			else
			{
				return;
			}
		}
	}
}

BOOL CWavePlay::AllocateMemory(DWORD dwBufferSize)
{
	Release(); // Release buffers

	// The number of playing queues we need
	m_dwQueue = (m_format.nChannels + m_format.wBitsPerSample / 8 + m_format.nSamplesPerSec / 11025);
	
	m_pArrHdr = new WAVEHDR*[m_dwQueue];
	m_pArrOutData = new BYTE*[m_dwQueue];
	if(!m_pArrHdr || !m_pArrOutData)
	{
		return FALSE;
	}
	else
	{
		memset(m_pArrOutData, 0, sizeof(BYTE*) * m_dwQueue);
		memset(m_pArrHdr, 0, sizeof(WAVEHDR*) * m_dwQueue);
	}

	// Left and right channel data for drawing
	if(m_hParentWnd && !m_rcDrawWnd.IsRectNull())
	{
		m_pByOutDataL = new BYTE[m_dwQueBufferSize];
		m_pByOutDataR = new BYTE[m_dwQueBufferSize];
		if(!m_pByOutDataL || !m_pByOutDataR)
		{
			return FALSE;
		}
		else
		{
			memset(m_pByOutDataL, 0, sizeof(BYTE) * m_dwQueBufferSize);
			memset(m_pByOutDataR, 0, sizeof(BYTE) * m_dwQueBufferSize);
		}
	}
	
	// Wave header and output data for playing
	for(int i = 0; i < m_dwQueue; i++)
	{
		m_pArrHdr[i] = new WAVEHDR;
		m_pArrOutData[i] = new BYTE[m_dwQueBufferSize];
		if(!m_pArrOutData[i] || !m_pArrHdr[i])
		{
			return FALSE;
		}
		else
		{
			memset(m_pArrOutData[i], 0, m_dwQueBufferSize);
			memset(m_pArrHdr[i], 0, sizeof(WAVEHDR));
		}
	}

	return TRUE;	
}

BOOL CWavePlay::ReadSoundDataFromFile(LPVOID pData, int& dwSize)
{
	if(!pData || dwSize <= 0)
	{
		return FALSE;
	}
	
	if(!m_hWaveFile)
	{
		return FALSE;
	}

	if(m_dwReadDataCount >= m_dwDataSize)
	{
		return FALSE;
	}

	mmioRead(m_hWaveFile, (HPSTR)pData, dwSize);

	m_dwReadDataCount += dwSize;
	if(m_dwReadDataCount > m_dwDataSize)
	{
		dwSize = dwSize - (m_dwReadDataCount - m_dwDataSize);
		if(dwSize <= 0)
		{
			return FALSE;
		}
	}

	m_nStepCount++;
	if((m_nStepCount % m_nStep2) == 0)
	{
		if(m_hParentWnd && GetParent()->m_hWnd)
		{
			::PostMessage(GetParent()->m_hWnd, WM_USER_PROGESS, m_nStepCount / m_nStep2, m_nRangeMax);
		}
	}

	return TRUE;
}

BOOL CWavePlay::AddOutputBufferToQueue(int nIndex, int nSize)
{
	MMRESULT mmResult = 0;

	if(nIndex < 0 || nIndex >= m_dwQueue)
	{
		return FALSE;
	}

	if(!m_pArrOutData[nIndex])
	{
		return FALSE;
	}
	
	// Create the header
	LPWAVEHDR pHdr = m_pArrHdr[nIndex];
	memset(pHdr, 0, sizeof(WAVEHDR));
	
	// New a buffer
	pHdr->lpData = (char*)m_pArrOutData[nIndex];
	pHdr->dwBufferLength = nSize;
	pHdr->dwBytesRecorded = nSize;
	pHdr->dwFlags = 0;
	pHdr->dwUser = nIndex;
	
	mmResult = waveOutPrepareHeader(m_hWaveOut, pHdr, sizeof(WAVEHDR));
	if(mmResult)
	{
		MyMessageBox(_T("waveOutPrepareHeader failed"), eERR_ERROR);
		return FALSE;
	}

	// Write the buffer to output queue
	mmResult = waveOutWrite(m_hWaveOut, pHdr, sizeof(WAVEHDR));
	if(mmResult) 
	{
		MyMessageBox(_T("waveOutWrite failed"), eERR_ERROR);
		return FALSE;
	}

	// Increment the number of waiting buffers
	m_dwBufferNumInQueue++;

	if(m_hParentWnd && !m_rcDrawWnd.IsRectNull())
	{
		// Pickup data for left and right channel and draw waveform with them
		int nPickup = SplitStereo2Mono(m_format, (PBYTE)pHdr->lpData, pHdr->dwBufferLength);
		DrawWave(nPickup);
	}
	
	return TRUE;	
}

void CWavePlay::Pause()
{
	MMRESULT mmResult = 0;

	if(m_hWaveOut == NULL)
	{
		return;
	}

	if(!m_bPlaying)
	{
		return;
	}

	mmResult = waveOutPause(m_hWaveOut);
	if(mmResult)
	{
		MyMessageBox(_T("waveOutPause failed"), eERR_ERROR);
	}
	else
	{
		m_bPaused = TRUE;
		m_bPlaying = FALSE;
	}
}

void CWavePlay::Restart()
{
	MMRESULT mmResult = 0;

	if(m_hWaveOut == NULL)
	{
		return;
	}

	m_bPaused = FALSE;
	m_bPlaying = TRUE;

	mmResult = waveOutRestart(m_hWaveOut);	
	if(mmResult)
	{
		MyMessageBox(_T("waveOutRestart failed"), eERR_ERROR);
	}
}

LRESULT CWavePlay::OnClose(WPARAM wParam, LPARAM lParam)
{
	Close();
	return 0L;
}

void CWavePlay::Stop()
{
	MMRESULT mmResult = 0;

	if(!m_hWaveOut)
	{
		return;
	}

	if(!m_bPlaying && !m_bPaused)
	{
		return;
	}

	// Because once you have called waveOutReset function
	// All pending playback buffers are marked as done and returned to the app
	// So, set the flag - m_bResetting true, then no functions about WAVE API
	// will be called in callback function - waveOutProc
	// Note:
	// When the waveOutReset API has called but not returned 
	// any other functions about WAVE API can't be called during this period
	// otherwise, there will be make a deadlock
	EnterCriticalSection(&g_CS);
	g_bResetting = TRUE;
	LeaveCriticalSection(&g_CS);

	mmResult = waveOutReset(m_hWaveOut);
	if(mmResult)
	{
		MyMessageBox(_T("waveOutReset failed"), eERR_ERROR);
	}
	
	g_bResetting = FALSE;

	Close(); // Unprepare headers and close waveform-audio output device

	if(m_hParentWnd && GetParent()->m_hWnd)
	{
		::PostMessage(GetParent()->m_hWnd, WM_USER_PROGESS, m_nRangeMax, m_nRangeMax);
	}
}

void CWavePlay::Close()
{
	MMRESULT mmResult = 0;

	if(m_hWaveOut == NULL)
	{
		return;
	}

	m_bPaused = FALSE;
	m_bPlaying = FALSE;
	
	// Note:
	// When playback interrupted and waveOutReset is called
	// All pending playback buffers are marked as done and returned to the app
	// So Cleans up them performed by the waveOutPrepareHeader function
	for(int i = 0; i < m_dwQueue; i++)
	{
		if((m_pArrHdr[i]->dwFlags & (WHDR_DONE | WHDR_PREPARED)) != 0)
		{
			while(waveOutUnprepareHeader(m_hWaveOut, m_pArrHdr[i], sizeof(WAVEHDR)) == WAVERR_STILLPLAYING) 
			{
				Sleep(1);
			}
		}
	}

	mmResult = waveOutClose(m_hWaveOut);
	if(mmResult)
	{
		MyMessageBox(_T("waveOutClose failed"), eERR_ERROR);
	}

	if(m_hWaveFile)
	{
		mmioClose(m_hWaveFile, 0);
	}
	
	Release();
	m_hWaveOut = NULL;
	m_hWaveFile = NULL;
	
	if(m_hParentWnd)
	{
		CClientDC dc(this);
		DrawWindowBG(&dc);
	}

	if(m_hParentWnd && GetParent()->m_hWnd)
	{
		::PostMessage(GetParent()->m_hWnd, WM_USER_PROGESS, m_nRangeMax, m_nRangeMax);
		::PostMessage(GetParent()->m_hWnd, WM_USER_CLOSE, 0L, 0L);
	}
}

void CWavePlay::GetDevNum(UINT &nDevNum)
{
	if(m_hWaveOut)
	{
		nDevNum = waveOutGetNumDevs();	
	}
}

void CWavePlay::GetDevID(UINT& nDevID)
{
	if(m_hWaveOut)
	{
		waveOutGetID(m_hWaveOut, &nDevID);	
	}
}

void CWavePlay::SetDevID(UINT nDevID)
{
	if(nDevID < waveOutGetNumDevs())
	{
		m_nDeviceID = nDevID;
	}
}

void CWavePlay::GetProductNames(CStringArray& strArrProductNames)
{
	WAVEOUTCAPS caps;
	
	strArrProductNames.RemoveAll();
	for(int i = 0; i < waveOutGetNumDevs(); i++)
	{
		waveOutGetDevCaps(i, &caps, sizeof(WAVEOUTCAPS));
		strArrProductNames.Add(caps.szPname);
	}
}

void CWavePlay::SetVolume(DWORD dwVolume)
{
	if(m_hWaveOut)
	{
		if((m_caps.dwSupport & WAVECAPS_VOLUME) != 0)
		{
			waveOutSetVolume(m_hWaveOut, dwVolume);
		}
		else
		{
			MyMessageBox(_T("Not supports volume control"), eERR_INFO);
		}
	}
}

void CWavePlay::SetVolumeLR(WORD wLeft, WORD wRight)
{
	if(m_hWaveOut)
	{
		if((m_caps.dwSupport & WAVECAPS_LRVOLUME) != 0)
		{
			DWORD dwVolume = (wRight << 16) | wLeft;
			waveOutSetVolume(m_hWaveOut, dwVolume);
		}
		else
		{
			MyMessageBox(_T("Not supports separate volume control"), eERR_INFO);
		}
	}
}

void CWavePlay::GetVolume(DWORD& dwVolume)
{
	if(m_hWaveOut)
	{
		if((m_caps.dwSupport & WAVECAPS_VOLUME) != 0)
		{
			waveOutGetVolume(m_hWaveOut, &dwVolume);
		}
		else
		{
			MyMessageBox(_T("Not supports volume control"), eERR_INFO);
		}
	}
}

void CWavePlay::GetVolumeLR(WORD& wLeft, WORD& wRight)
{
	if(m_hWaveOut)
	{
		if((m_caps.dwSupport & WAVECAPS_LRVOLUME) != 0)
		{
			DWORD dwVolume = 0;
			waveOutGetVolume(m_hWaveOut, &dwVolume);
			wLeft = dwVolume & 0xffff;
			wRight = (dwVolume >> 16) & 0xffff;
		}
		else
		{
			MyMessageBox(_T("Not supports separate volume control"), eERR_INFO);
		}
	}
}

void CWavePlay::SetPitch(DWORD dwPitch)
{
	if(m_hWaveOut)
	{
		if((m_caps.dwSupport & WAVECAPS_PITCH) != 0)
		{
			waveOutSetPitch(m_hWaveOut, dwPitch);
		}
		else
		{
			MyMessageBox(_T("Not supports pitch control"), eERR_INFO);
		}
	}
}

void CWavePlay::GetPitch(DWORD& dwPitch)
{
	if(m_hWaveOut)
	{
		if((m_caps.dwSupport & WAVECAPS_PITCH) != 0)
		{
			waveOutGetPitch(m_hWaveOut, &dwPitch);
		}
		else
		{
			MyMessageBox(_T("Not supports pitch control"), eERR_INFO);
		}
	}
}

void CWavePlay::SetPlaybackRate(DWORD dwRate)
{
	if(m_hWaveOut)
	{
		if((m_caps.dwSupport & WAVECAPS_PLAYBACKRATE) != 0)
		{
			waveOutSetPlaybackRate(m_hWaveOut, dwRate);
		}
		else
		{
			MyMessageBox(_T("Not supports playback rate control"), eERR_INFO);
		}
	}
}

void CWavePlay::GetPlaybackRate(DWORD& dwRate)
{
	if(m_hWaveOut)
	{
		if((m_caps.dwSupport & WAVECAPS_PLAYBACKRATE) != 0)
		{
			waveOutGetPlaybackRate(m_hWaveOut, &dwRate);
		}
		else
		{
			MyMessageBox(_T("Not supports playback rate control"), eERR_INFO);
		}
	}
}

void CWavePlay::SetPosition(long lPos)
{
	if(m_hWaveFile)
	{
		long lCurrPos = mmioSeek(m_hWaveFile, 0, SEEK_CUR);
		long lOffset = m_nInitPos + lPos * m_nStep2 * m_dwQueBufferSize;
		lOffset = lOffset - lCurrPos;
		m_nStepCount = lPos * m_nStep2;
		mmioSeek(m_hWaveFile, lOffset, SEEK_CUR);
	}
}

LRESULT CWavePlay::OnMM_WOM_CLOSE(WPARAM wParam, LPARAM lParam)
{
	return 0L;
}

LRESULT CWavePlay::OnMM_WOM_DONE(WPARAM wParam, LPARAM lParam)
{
	MMRESULT mmResult = 0;
	LPWAVEHDR pHdr = (LPWAVEHDR)lParam;
	
	if(!g_bResetting)
	{
		if(m_hWaveOut)
		{
			mmResult = waveOutUnprepareHeader(m_hWaveOut, pHdr, sizeof(WAVEHDR));
			if(mmResult)
			{
				MyMessageBox(_T("waveOutUnprepareHeader failed1"), eERR_ERROR);
				return FALSE;
			}

			m_dwBufferNumInQueue--;
		
			if(m_bPlaying || m_bPaused)
			{
				int nSize = m_dwQueBufferSize;
				if(ReadSoundDataFromFile(pHdr->lpData, nSize))
				{
					AddOutputBufferToQueue((int)pHdr->dwUser, nSize);
					return 0L;
				}
			}
			if(m_dwBufferNumInQueue <= 0)
			{
				Close();
			}
		}
	}
	
	return 0L;
}

BOOL CWavePlay::waveOutProc(HWAVEOUT hWaveOut, UINT uMsg, DWORD dwInstance, DWORD dwParam1, DWORD dwParam2)
{
	BOOL bResult = TRUE;
	MMRESULT mmResult = 0;
	LPWAVEHDR pHdr = (LPWAVEHDR)dwParam1;
	CWavePlay* pWavePlay = (CWavePlay*)dwInstance;

	EnterCriticalSection(&g_CS);

	switch(uMsg)
	{
	case WOM_OPEN: break;

	case WOM_CLOSE: break;
		
	case WOM_DONE:
		if(!g_bResetting)
		{
			mmResult = waveOutUnprepareHeader(hWaveOut, pHdr, sizeof(WAVEHDR));
			if(mmResult)
			{
				bResult = FALSE;
				pWavePlay->MyMessageBox(_T("waveOutUnprepareHeader failed"), eERR_ERROR);
				break;
			}
		
			pWavePlay->m_dwBufferNumInQueue--;
			
			if(pWavePlay->m_bPlaying || pWavePlay->m_bPaused)
			{
				int nSize = pWavePlay->m_dwQueBufferSize;
				if(pWavePlay->ReadSoundDataFromFile(pHdr->lpData, nSize))
				{
					pWavePlay->AddOutputBufferToQueue((int)pHdr->dwUser, nSize);
					break;
				}
			}
			
			if(pWavePlay->m_dwBufferNumInQueue <= 0)
			{
				pWavePlay->PostMessage(WM_USER_CLOSE, 0L, 0L);
			}
		}
	}

	LeaveCriticalSection(&g_CS);

	return bResult;
}
